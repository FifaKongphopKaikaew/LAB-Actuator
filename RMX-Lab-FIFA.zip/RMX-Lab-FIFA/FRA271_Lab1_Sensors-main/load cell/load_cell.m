clc;
clear;
cd 3rd_data\
start_file_num = 0;
end_file_num = 20;

num_files = end_file_num - start_file_num + 1;

all_averages = zeros(1, num_files);

for i = start_file_num:end_file_num

    % fill data loop
    filename = sprintf('kg%d.mat', i);
    
    % Check loaded files
    if isfile(filename)
        % loading file into S struct
        S = load(filename);
        
        % mean
        avg_value = mean(S.data.Data);
        % put it in matrix
        array_index = i - start_file_num + 1;
        all_averages(array_index) = avg_value;

        fprintf('File %s, mean = %.4f (kept in index %d)\n', filename, avg_value, i);
    else
        fprintf('!!! File not Found: %s \n', filename);
        all_averages(i) = NaN;
    end
end

incremental_weights = [0, 498, 503, 490, 501, 506, 478, 493, 508, 494, 494, 507, 496, 495, 494, 494, 503, 517, 481, 504, 520];

if length(incremental_weights) ~= num_files
    error('N files is not matches .mat!');
end

%Cumulative Sum
y_known_weight_g = cumsum(incremental_weights);

%linear equation
x_raw_signal = all_averages;

P = polyfit(x_raw_signal, y_known_weight_g, 1);

m_slope = P(1);
c_offset = P(2);

fprintf('\nCalibration Equation (Actual Weights)\n');
fprintf('Weight = (%.6f * RawSignal) + (%.4f)\n', m_slope, c_offset);

y_fit = (m_slope * x_raw_signal) + c_offset;

figure;

figure; 
% พล็อตจุดข้อมูลจริง (x=สัญญาณ, y=น้ำหนักจริง)
plot(x_raw_signal, y_known_weight_g, 'bo', 'MarkerSize', 8, 'DisplayName', 'ข้อมูลวัดจริง');
hold on;
% พล็อตเส้นที่คำนวณได้
plot(x_raw_signal, y_fit, 'r-', 'LineWidth', 2, 'DisplayName', 'เส้น Calibration (Polyfit)');

for i = 1:length(x_raw_signal)
    
    % ดึงค่า X และ Y ของจุดปัจจุบัน
    current_x = x_raw_signal(i);
    current_y = y_known_weight_g(i);
    
    % สร้างข้อความ (ในที่นี้เราจะแสดงค่าน้ำหนัก Y โดยปัดเศษ)
    label = sprintf('%.0f g', current_y); 
    
    % วาดข้อความลงบนกราฟ
    text(current_x, current_y, label, ...
         'VerticalAlignment', 'bottom', ...  % ให้ข้อความอยู่ "เหนือ" จุด
         'HorizontalAlignment', 'center', ... % ให้อยู่ "กึ่งกลาง" จุด
         'FontSize', 8, ...
         'Color', 'blue'); 
end

hold off;
title('Load Cell Calibration Curve (Actual Weights)');
xlabel('Average Raw Signal (grams)');
ylabel('Cumulative Weight (grams)');
legend('Location', 'northwest');
grid on;

%95.75 ohm
%n[0,1,2,3,4,5,6,...,19,20] 
% [0,498,503,490,501,506,478,493,508,494,494,507,496,495,494,494,503,517,481,504,520]