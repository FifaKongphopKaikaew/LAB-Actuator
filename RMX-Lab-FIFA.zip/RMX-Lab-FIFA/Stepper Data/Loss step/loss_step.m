%==========================================================================
% SCRIPT NAME: compare_single_files.m
% DESCRIPTION: Load only file *_1.mat from each folder, Filter, and Plot
%==========================================================================
clc; clear; close all;

%% 1. Configuration - กำหนดค่าเริ่มต้น

% === ตั้งค่าโฟลเดอร์และไฟล์ ===
base_dir = 'Loss step'; 

% กำหนดรายการไฟล์: { 'ชื่อ Folder', 'prefix ของไฟล์', 'ชื่อสำหรับกราฟ' }
file_map = {
    'full', 'full_', '1';
    'half', 'half_', '1';
    '14',   '14_',   'Micro 1/4';
    '18',   '18_',   'Micro 1/8';
    '116',  '16_',   'Micro 1/16'; % Folder 116 แต่ไฟล์ขึ้นต้นด้วย 16
    '132',  '32_',   'Micro 1/32'  % Folder 132 แต่ไฟล์ขึ้นต้นด้วย 32
};

% *** แก้ไขตรงนี้: เลือกเฉพาะไฟล์เบอร์ 1 เท่านั้น ***
target_file_index = 1; 

% === การตั้งค่า Filter ===
Fs = 1000;              % Sampling frequency (Hz)
N_order = 4;            % Filter Order 
Fc_norm = 0.05;         % Normalized Cutoff (ปรับตามความเหมาะสม)

% เตรียมตัวแปรเก็บข้อมูล
all_signals = struct('name', {}, 'raw', {}, 'filtered', {});
count = 0;

% ออกแบบ Filter (Butterworth Lowpass)
[b, a] = butter(N_order, Fc_norm, 'low');

%% 2. Processing Loop - โหลดและกรองสัญญาณ

fprintf('Starting data loading (Only files ending in _%d.mat)...\n', target_file_index);

for i = 1:size(file_map, 1)
    folder_name = file_map{i, 1};
    file_prefix = file_map{i, 2};
    label_base  = file_map{i, 3};
    
    % สร้างชื่อไฟล์: เช่น Loss step/14/14_1.mat
    filename = [file_prefix, num2str(target_file_index), '.mat'];
    full_path = fullfile(base_dir, folder_name, filename);
    
    if isfile(full_path)
        count = count + 1;
        try
            % --- 2.1 Load Data ---
            raw_data = extract_data_auto(full_path);
            
            % --- 2.2 FFT Analysis (Optional) ---
            % ถ้าอยากดูกราฟความถี่ของ Noise ให้ Uncomment บรรทัดนี้
            % plot_fft(raw_data, Fs, label_base);
            
            % --- 2.3 Apply Lowpass Filter ---
            % ใช้ filtfilt (Zero-phase) เพื่อไม่ให้กราฟเลื่อน
            filtered_data = filtfilt(b, a, raw_data);
            
            % --- 2.4 Store Data ---
            all_signals(count).name = label_base;
            all_signals(count).raw = raw_data;
            all_signals(count).filtered = filtered_data;
            
            fprintf('  > Loaded & Filtered: %s\n', label_base);
            
        catch ME
            fprintf('  ! Error processing %s: %s\n', full_path, ME.message);
        end
    else
        fprintf('  ! File not found: %s\n', full_path);
    end
end

%% 3. Plotting - พล็อตกราฟเปรียบเทียบในรูปเดียว

if count > 0
    figure('Name', 'Stepping Mode Comparison (File 1 Only)', 'Color', 'w', 'Position', [100 100 1000 600]);
    hold on; grid on;
    
    colors = lines(count); % สร้างชุดสีตามจำนวนไฟล์ที่เจอ
    
    for k = 1:count
        % พล็อตข้อมูลที่กรองแล้ว
        plot(all_signals(k).filtered, 'Color', colors(k,:), 'LineWidth', 2, ...
             'DisplayName', all_signals(k).name);
    end
    
    title(['Comparison of Velocity Signals (Filter Cutoff = ' num2str(Fc_norm) ' \times Fs/2)']);
    xlabel('Time (Samples)');
    ylabel('Velocity / Amplitude');
    legend('show', 'Location', 'best');
    hold off;
else
    fprintf('ไม่พบไฟล์ข้อมูลเลย กรุณาตรวจสอบ Path\n');
end

%% ========================================================================
%  LOCAL FUNCTIONS
%  ========================================================================

function numeric_data = extract_data_auto(filepath)
    % ฟังก์ชันโหลดไฟล์และหาตัวแปรตัวเลขตัวแรกอัตโนมัติ
    S = load(filepath);
    vars = fieldnames(S);
    found = false;
    for i = 1:length(vars)
        data = S.(vars{i});
        if isa(data, 'timeseries')
            numeric_data = data.Data;
            found = true; break;
        elseif isnumeric(data) && numel(data) > 1
            numeric_data = data;
            found = true; break;
        end
    end
    if ~found, error('No suitable numeric data found'); end
    if isrow(numeric_data), numeric_data = numeric_data'; end
    numeric_data = double(numeric_data);
end

function plot_fft(data, Fs, label)
    % ฟังก์ชันพล็อต FFT
    L = length(data);
    Y = fft(data);
    P2 = abs(Y/L);
    P1 = P2(1:floor(L/2)+1);
    P1(2:end-1) = 2*P1(2:end-1);
    f = Fs*(0:floor(L/2))/L;
    
    figure; plot(f, P1); 
    title(['FFT Spectrum: ' label]); xlabel('Hz'); grid on;
end