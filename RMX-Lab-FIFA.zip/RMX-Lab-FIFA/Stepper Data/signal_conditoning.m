%==========================================================================
% SCRIPT NAME: four_subplot_butterworth_2nd_order.m 
% DESCRIPTION: Loads micro18_1.mat, uses a 2nd Order Butterworth Lowpass 
%              Filter, and plots the analysis in 4 subplots.
%==========================================================================
%% 1. Configuration - กำหนดค่าเริ่มต้น

num_files = 1; 
base_filename = 'halfstep';
file_extension = '.mat'; 
variable_name_in_file = 'data'; 

% === การตั้งค่า Butterworth Filter (2nd Order) ===
Fs = 1000;              % Sampling frequency (Hz) **สำคัญ: ต้องปรับตามข้อมูลจริง**
N_order = 2;            % <--- กำหนดเป็น 2nd Order
Fc_ratio = 0.07;        % Normalized Cutoff Frequency (0.07 * Fs/2 = 35 Hz)

start_index = 3;        % โหลดไฟล์ micro18_1.mat เท่านั้น

% เตรียมที่เก็บข้อมูล
all_data = cell(1, num_files);          
all_filtered_data = cell(1, num_files); 

% ออกแบบ Lowpass Filter (พยายามใช้ Butterworth ก่อน)
try
    % Design Low-Pass Butterworth filter (2nd Order)
    [b, a] = butter(N_order, Fc_ratio, 'low'); 
    filter_type = 'Butterworth (2nd Order)';
catch
    % Fallback หากไม่มี Signal Processing Toolbox
    b = [];
    a = [];
    filter_type = 'Moving Mean (Fallback)';
    warning('MATLAB:ToolboxMissing', 'Signal Processing Toolbox required for Butterworth filter. Using Moving Mean fallback.');
end


%% 2. Helper Function - ฟังก์ชันช่วยในการดึงข้อมูลตัวเลข (Data)

% (*** ฟังก์ชันเดียวกันกับที่ท่านให้มา ***)
function numeric_data = extract_main_data_wrapper(filepath, var_name)
    S = load(filepath);
    
    if isfield(S, var_name)
        loaded_var = S.(var_name);
    else
        error('Variable "%s" not found in file.', var_name);
    end
    
    if isobject(loaded_var) && strcmp(class(loaded_var), 'timeseries')
        numeric_data = loaded_var.Data;
    elseif isnumeric(loaded_var)
        numeric_data = loaded_var;
    else
        error('Variable is not numeric or a recognized TimeSeries object.');
    end
    
    if isrow(numeric_data)
        numeric_data = numeric_data';
    end
end


%% 3. Loading and Filtering - โหลดและกรองสัญญาณ

fprintf('Starting data analysis for file micro18_%d.mat (2nd Order Filter)...\n', start_index);

try
    file_num = start_index; 
    current_filename = [base_filename, num2str(file_num), file_extension];
    velocity_file = fullfile(current_filename);
    data_to_compare = extract_main_data_wrapper(velocity_file, variable_name_in_file);
    all_data{1} = data_to_compare; 
    
    % ******************************************************
    % *** Apply Butterworth Filter (2nd Order) ***
    % ******************************************************
    if ~isempty(b) % ใช้ Butterworth Filter
        filtered_data = filtfilt(b, a, data_to_compare); % Zero-phase filtering
    else % ใช้ Moving Mean (Fallback)
        smoothing_window = round(1 / Fc_ratio); % ประมาณ Window Size ตาม Fc
        filtered_data = smoothdata(data_to_compare, 'movmean', smoothing_window);
    end
    
    all_filtered_data{1} = filtered_data;
    
    % *** คำนวณ FFT Spectrum สำหรับการพลอต ***
    N = length(data_to_compare);
    Y = fft(data_to_compare);
    P2 = abs(Y/N);
    P1_raw = P2(1:floor(N/2)+1);
    P1_raw(2:end-1) = 2*P1_raw(2:end-1);
    f = Fs*(0:floor(N/2))/N;
    
    % คำนวณ FFT Filtered Data
    Y_filtered_fft = fft(filtered_data);
    P2_filtered = abs(Y_filtered_fft/N);
    P1_filtered = P2_filtered(1:floor(N/2)+1);
    P1_filtered(2:end-1) = 2*P1_filtered(2:end-1);
    
    % *** คำนวณ Magnitude Response สำหรับ Subplot 4 ***
    Fc_value = Fc_ratio * (Fs/2);
    try
        % ใช้ freqz ของ Filter ที่ออกแบบด้วย Butterworth
        [H, w] = freqz(b, a, 1024, Fs);
        Magnitude_dB = 20*log10(abs(H));
        Frequency_Hz = w;
    catch
        % Fallback สำหรับกรณีที่ไม่มี freqz (Filter Response Plot จะผิดเพี้ยน)
        warning('MATLAB:FreqzError', 'Cannot plot accurate Magnitude Response (Toolbox/Function Missing).');
        Magnitude_dB = zeros(10, 1);
        Frequency_Hz = linspace(0, Fs/2, 10);
    end
    
    fprintf('  > Successfully processed and filtered file %s.\n', current_filename);
    
catch ME
    warning('MATLAB:ProcessingError', 'Could not process file %s. Error: %s', current_filename, ME.message);
    data_to_compare = []; filtered_data = []; P1_raw = []; P1_filtered = []; f = [];
    Magnitude_dB = zeros(10, 1); Frequency_Hz = linspace(0, Fs/2, 10);
end


%% 4. Plotting Comparison - พล็อตกราฟเปรียบเทียบ (2x2 Subplots)

figure('Name', ['4-Subplot Analysis: ', current_filename, ' (', filter_type, ')'], 'NumberTitle', 'off');

%---------------------------------------------------
% Subplot 1 (บนซ้าย): Raw Data (Time Domain)
%---------------------------------------------------
subplot(2, 2, 1); 
plot(data_to_compare, 'b', 'LineWidth', 1.5, 'DisplayName', 'Raw Data');
title('1. Raw Data (Time Domain)');
xlabel('Sample Index');
ylabel('Value'); 
grid on;
legend('show', 'Location', 'best');

%---------------------------------------------------
% Subplot 2 (บนขวา): Filtered Data (Time Domain)
%---------------------------------------------------
subplot(2, 2, 2); 
plot(filtered_data, 'r', 'LineWidth', 2, 'DisplayName', 'Filtered Data');
title('2. Filtered Data (Time Domain)');
xlabel('Sample Index');
ylabel('Filtered Value'); 
grid on;
legend('show', 'Location', 'best');

%---------------------------------------------------
% Subplot 3 (ล่างซ้าย): FFT Spectrum (Raw Data)
%---------------------------------------------------
subplot(2, 2, 3); 
plot(f, P1_raw, 'b', 'LineWidth', 1.5, 'DisplayName', 'Raw FFT Spectrum');
hold on;
plot([Fc_value, Fc_value], [0, max(P1_raw)*1.1], 'r--', 'LineWidth', 2, 'DisplayName', ['Cutoff Fc: ', num2str(Fc_value), ' Hz']);
hold off;
title('3. FFT Spectrum (Raw Data) & Cutoff');
xlabel('Frequency (Hz)');
ylabel('|Amplitude|'); 
grid on;
legend('show', 'Location', 'northeast');

%---------------------------------------------------
% Subplot 4 (ล่างขวา): Lowpass Filter Magnitude Response (Butterworth)
%---------------------------------------------------
subplot(2, 2, 4); 
plot(Frequency_Hz, Magnitude_dB, 'g', 'LineWidth', 2, 'DisplayName', [num2str(N_order), 'th Order Filter']);
hold on;
% วาดเส้น -3 dB ที่ Cutoff Frequency (Fc)
plot([Fc_value, Fc_value], [-40, 0], 'r--', 'LineWidth', 1.5, 'DisplayName', '-3 dB Cutoff');
plot([0, Fs/2], [-3, -3], 'k:', 'DisplayName', '-3 dB Line');
hold off;

title(['4. ', num2str(N_order), 'th Order Filter Magnitude Response (Gain)']);
xlabel('Frequency (Hz)');
ylabel('Magnitude (dB)'); 
ylim([-40, 5]); 
grid on;
legend('show', 'Location', 'southwest');

fprintf('Script execution finished. 4-Subplot Figure displayed.\n');

% ล้างฟังก์ชันช่วยออกไปจาก Workspace
clear extract_main_data_wrapper;