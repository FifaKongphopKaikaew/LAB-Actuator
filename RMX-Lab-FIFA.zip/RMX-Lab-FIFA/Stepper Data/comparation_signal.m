clc; clear; close all;

% --- 1. ตั้งค่าพารามิเตอร์ ---
Fs = 1000;      % Sampling Frequency (Hz) **อย่าลืมปรับให้ตรงกับความเป็นจริง**
Fc = 30;        % Cutoff Frequency (Hz) ค่าความถี่ที่จะเริ่มตัด Noise

% รายชื่อไฟล์และโฟลเดอร์
fileList = {
    '14/micro14_1.mat',       'Micro 1/4';
    '18/micro18_1.mat',       'Micro 1/8';
    '116/micro116_1.mat',     'Micro 1/16';
    '132/micro132_1.mat',     'Micro 1/32';
    'Full Step/fullstep1.mat','Full Step';
    'Half Step/halfstep1.mat','Half Step'
};

% สร้าง Figure รอไว้
figure('Name', 'Velocity Comparison', 'Color', 'w');
hold on;
grid on;
title(['Comparison of Filtered Velocity Signals (Cutoff = ' num2str(Fc) ' Hz)']);
xlabel('Frequancy (Hz)');
ylabel('Velocity (Rad/s)');

colors = lines(size(fileList, 1)); 

% --- 2. วนลูปโหลดและประมวลผล ---
for i = 1:size(fileList, 1)
    filePath = fileList{i, 1};
    legendName = fileList{i, 2};
    
    if exist(filePath, 'file')
        loadedData = load(filePath);
        varNames = fieldnames(loadedData);
        tempData = loadedData.(varNames{1}); % ดึงตัวแปรแรกออกมาพักไว้ก่อน
        
        % === ส่วนที่แก้ไข: ตรวจสอบประเภทข้อมูลและดึงค่าออกมา ===
        if isa(tempData, 'timeseries')
            % กรณีเป็น timeseries object (Simulink)
            rawSignal = tempData.Data;
        elseif isstruct(tempData) && isfield(tempData, 'signals')
            % กรณีเป็น Structure with time
            rawSignal = tempData.signals.values;
        else
            % กรณีเป็น Array ตัวเลขปกติ
            rawSignal = tempData;
        end
        
        % แปลงให้เป็น double precision แน่นอน เพื่อป้องกัน Error
        rawSignal = double(rawSignal);
        
        % กำจัดมิติเกิน (เช่น เป็น 1x1xN ให้เหลือ N)
        rawSignal = squeeze(rawSignal);
        
        % ถ้าข้อมูลนอนเป็นแนวนอน ให้กลับเป็นแนวตั้ง
        if size(rawSignal, 2) > size(rawSignal, 1)
            rawSignal = rawSignal';
        end
        % =================================================
        
        % --- ขั้นตอนการ Filter (Lowpass) ---
        try
            % ใช้ filtfilt (Butterworth Lowpass)
            % สร้าง Filter coefficients (4th order)
            [b, a] = butter(4, Fc/(Fs/2), 'low'); 
            filteredSignal = filtfilt(b, a, rawSignal);
        catch ME
            fprintf('Error filtering %s: %s\n', legendName, ME.message);
            continue; 
        end
        
        % --- 3. Plot ---
        plot(filteredSignal, 'LineWidth', 1.5, 'DisplayName', legendName, 'Color', colors(i,:));
        
    else
        fprintf('หาไฟล์ไม่เจอ: %s\n', filePath);
    end
end

legend('show', 'Location', 'best');
hold off;