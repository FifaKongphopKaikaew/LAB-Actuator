%==========================================================================
% SCRIPT NAME: combined_lowpass_script.m (Combined Timeseries Handler & Filter)
% DESCRIPTION: Loads multiple files, converts timeseries data, applies 
%              a Lowpass Filter (Butterworth or Fallback), and plots results.
%==========================================================================
%% 1. Configuration - กำหนดค่าเริ่มต้น

num_files = 3; 
base_filename = 'micro116_';
file_extension = '.mat'; 
variable_name_in_file = 'data'; % ชื่อตัวแปร (Array) ภายในไฟล์ .mat ที่ต้องการโหลด

% === การตั้งค่า Filter (Butterworth / Fallback) ===
Fs = 1000;              % Sampling frequency (Hz) **สำคัญ: ต้องปรับตามข้อมูลจริง**
N_order = 2;           % Filter Order
Fc_norm = 0.05;         % Normalized Cutoff Frequency (0.05 * Fs/2)
smoothing_window = 20;  % สำหรับ Fallback Filter (smoothdata)

% === การตั้งค่าเริ่มต้นของ Index ไฟล์ ===
start_index = 1;        % ถ้าไฟล์เริ่มต้นที่ micro14_4400.mat ให้เปลี่ยนเป็น 4400 

% เตรียมที่เก็บข้อมูลและผลลัพธ์
all_data = cell(1, num_files);          
all_filtered_data = cell(1, num_files); 
legend_labels = cell(1, num_files); 

% ออกแบบ Lowpass Filter (พยายามใช้ Butterworth ก่อน)
try
    [b, a] = butter(N_order, Fc_norm, 'low'); % Design Low-Pass Butterworth filter
    filter_type = 'Butterworth (Zero-Phase)';
catch
    b = [];
    a = [];
    filter_type = ['Moving Mean (Fallback, Window: ', num2str(smoothing_window), ')'];
end
fprintf('Filter Type Selected: %s\n', filter_type);

%% 2. Helper Function - ฟังก์ชันช่วยในการดึงข้อมูลตัวเลข (Data)

% ฟังก์ชันช่วยในการดึงข้อมูลตัวเลข (Data) ออกจากไฟล์ .mat (แก้ปัญหา Timeseries)
function numeric_data = extract_main_data_wrapper(filepath, var_name)
    S = load(filepath);
    
    if isfield(S, var_name)
        loaded_var = S.(var_name);
    else
        error('Variable "%s" not found in file.', var_name);
    end
    
    % ดึงค่าตัวเลขจาก Field .Data (สำหรับ Timeseries Object)
    if isobject(loaded_var) && strcmp(class(loaded_var), 'timeseries')
        numeric_data = loaded_var.Data;
    elseif isnumeric(loaded_var)
        numeric_data = loaded_var;
    else
        error('Variable is not numeric or a recognized TimeSeries object.');
    end
    
    % ทำให้มั่นใจว่าเป็น Column Vector
    if isrow(numeric_data)
        numeric_data = numeric_data';
    end
end
%% 3. Pre-Analysis: FFT Spectrum (สำหรับไฟล์แรก)

try
    first_filename = [base_filename, num2str(start_index), file_extension];
    data_for_fft = extract_main_data_wrapper(first_filename, variable_name_in_file);
    
    N_fft = length(data_for_fft);
    Y = fft(data_for_fft);
    
    % คำนวณ Single-Sided Amplitude Spectrum (P1)
    P2 = abs(Y/N_fft);
    P1 = P2(1:floor(N_fft/2)+1);
    P1(2:end-1) = 2*P1(2:end-1);
    f = Fs*(0:floor(N_fft/2))/N_fft;
    
    % พล็อต FFT
    figure('Name', ['FFT Analysis for ', first_filename], 'NumberTitle', 'off');
    plot(f, P1, 'b', 'LineWidth', 1.5);
    title(['FFT Spectrum for Micro18 (File ', num2str(start_index), ')']);
    xlabel('Frequency (Hz)');
    ylabel('|Amplitude|');
    grid on;
    
    fprintf('  > FFT Spectrum displayed. Please close the FFT figure and adjust Fc_norm in Section 1 if needed.\n');
    
catch ME
    warning('MATLAB:FFTAnalysis', 'Could not perform FFT analysis on file %s. Error: %s', first_filename, ME.message);
end

%% 3. Looping, Loading, and Filtering - วนลูป โหลด และกรองสัญญาณ

fprintf('Starting data loading and filtering...\n');

for k = 1:num_files
                                                                                                                
    file_num = start_index + (k - 1); 
    current_filename = [base_filename, num2str(file_num), file_extension];
    legend_labels{k} = ['Experiment ', num2str(file_num)];
    
    try
        % 4.1. โหลดไฟล์และจัดการ Timeseries
        velocity_file = fullfile(current_filename);
        data_to_compare = extract_main_data_wrapper(velocity_file, variable_name_in_file);
        all_data{k} = data_to_compare; 
        
        % 4.2. Apply Filter
        if ~isempty(b) % ใช้ Butterworth Filter
            filtered_data = filtfilt(b, a, data_to_compare); 
        else % ใช้ Moving Mean (Fallback)
            filtered_data = smoothdata(data_to_compare, 'movmean', smoothing_window);
        end
        
        all_filtered_data{k} = filtered_data;
        
        fprintf('  > Successfully processed file %s.\n', current_filename);
        
    catch ME
        warning('MATLAB:ProcessingError', 'Could not process file %s. Error: %s', current_filename, ME.message);
    end
end
fprintf('Loading and filtering complete.\n');


%% 4. Plotting Comparison - พล็อตกราฟเปรียบเทียบ

figure('Name', 'Data Comparison: Raw vs. Filtered', 'NumberTitle', 'off');

%---------------------------------------------------
% Subplot 1: Overlay Line Plot (เปรียบเทียบเส้นกราฟดิบ)
%---------------------------------------------------
subplot(2, 1, 1); 
hold on; 
for j = 1:num_files
    if ~isempty(all_data{j})
        plot(all_data{j}, 'LineWidth', 1.5, 'DisplayName', legend_labels{j}); 
    end
end
hold off;
title('Comparison of Raw Data Arrays (Original)');
xlabel('Frequancy (Hz)');
ylabel('Angular Velocity (rad/s)'); 
legend('show', 'Location', 'best');
grid on;

%---------------------------------------------------
% Subplot 2: Overlay Line Plot (เปรียบเทียบเส้นกราฟที่ผ่านการกรองแล้ว)
%---------------------------------------------------
subplot(2, 1, 2); 
hold on; 
for j = 1:num_files
    if ~isempty(all_filtered_data{j})
        % พล็อตข้อมูลที่ผ่านการกรองแล้ว (ตาม condition ที่ได้มา)
        plot(all_filtered_data{j}, 'LineWidth', 2, 'DisplayName', legend_labels{j}); 
    end
end
hold off;
title(['Comparison of Data After Filtering (Type: ', filter_type, ')']);
xlabel('Frequancy (Hz)');
ylabel('Angular Velocity (rad/s'); 
legend('show', 'Location', 'best');
grid on;

fprintf('Script execution finished. Figures displayed.\n');

% ล้างฟังก์ชันช่วยออกไปจาก Workspace
clear extract_main_data_wrapper;