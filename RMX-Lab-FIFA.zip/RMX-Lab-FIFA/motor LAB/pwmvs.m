% ============================================================
% MATLAB Script: PWM Frequency vs Duty Cycle Analysis
% ============================================================
clc; clear; close all;

% --- 1. ตั้งค่า Motor Constants (ใช้ชุดเดิม) ---
V_in = 12;      % Voltage (V)
T_st = 0.2;     % Stall Torque (Nm)
I_st = 4.9;     % Stall Current (A)
I_nl = 0.2;     % No-Load Current (A)

% คำนวณค่าคงที่มอเตอร์
kt = T_st / (I_st - I_nl); 

% --- 2. การตั้งค่าการโหลดข้อมูล ---
prompt = {'ระบุจำนวนชุดข้อมูลที่ต้องการเปรียบเทียบ (เช่น 1, 2, 3):'};
dlgtitle = 'Setup';
dims = [1 50];
definput = {'2'}; % ค่า default คือ 2 ชุด
answer = inputdlg(prompt,dlgtitle,dims,definput);
if isempty(answer), return; end
num_datasets = str2double(answer{1});

% เตรียมตัวแปร Structure สำหรับเก็บข้อมูลแต่ละชุด
datasets(num_datasets) = struct('freq', [], 'pwm_axis', [], 'rpm', [], 'curr', [], 'eff', []);

% --- 3. Loop เพื่อโหลดไฟล์ทีละชุด ---
for i = 1:num_datasets
    fprintf('\n=== โหลดข้อมูลชุดที่ %d/%d ===\n', i, num_datasets);
    
    % รับค่าความถี่ของชุดนี้
    freq_ans = inputdlg({['ระบุความถี่ PWM ของชุดที่ ' num2str(i) ' (Hz):']}, ...
                        'Frequency Input', [1 50], {'1000'});
    if isempty(freq_ans), return; end
    current_freq_val = str2double(freq_ans{1});
    
    try
        % 3.1 Load Files
        disp(['>> กรุณาเลือกไฟล์ PWM.mat สำหรับ ' num2str(current_freq_val) ' Hz']);
        [f, p] = uigetfile('*.mat', ['1. เลือกไฟล์ PWM (ชุด ' num2str(i) ')']);
        if f==0, return; end; t=load(fullfile(p,f)); v=fieldnames(t); raw_pwm=convertToDoubleArray(t.(v{1}));

        disp(['>> กรุณาเลือกไฟล์ Omega/Speed สำหรับ ' num2str(current_freq_val) ' Hz']);
        [f, p] = uigetfile('*.mat', ['2. เลือกไฟล์ Speed (ชุด ' num2str(i) ')']);
        if f==0, return; end; t=load(fullfile(p,f)); v=fieldnames(t); raw_omega=convertToDoubleArray(t.(v{1}));
        
        disp(['>> กรุณาเลือกไฟล์ Current สำหรับ ' num2str(current_freq_val) ' Hz']);
        [f, p] = uigetfile('*.mat', ['3. เลือกไฟล์ Current (ชุด ' num2str(i) ')']);
        if f==0, return; end; t=load(fullfile(p,f)); v=fieldnames(t); raw_curr=convertToDoubleArray(t.(v{1}));
        
        % 3.2 Process Data
        min_len = min([length(raw_pwm), length(raw_omega), length(raw_curr)]);
        N = min(min_len, 200000); % Limit points
        
        pwm_cut = raw_pwm(1:N);
        omega_cut = raw_omega(1:N);
        curr_cut = raw_curr(1:N);
        
        % แปลง PWM 0-65000 -> 0-100%
        pwm_percent = (pwm_cut / 65000) * 100;
        
        % 3.3 Binning / Averaging (หาค่าเฉลี่ยตาม % Duty Cycle)
        target_pwm = 0 : 2 : 100; % Step ทีละ 2%
        avg_rpm = nan(size(target_pwm));
        avg_cur = nan(size(target_pwm));
        
        for k = 1:length(target_pwm)
            cp = target_pwm(k);
            % หาช่วง PWM +/- 1%
            idx = find(pwm_percent >= (cp - 1) & pwm_percent < (cp + 1));
            if ~isempty(idx)
                avg_rpm(k) = mean(omega_cut(idx));
                avg_cur(k) = mean(curr_cut(idx));
            end
        end
        
        % Clean NaNs
        valid = ~isnan(avg_rpm) & ~isnan(avg_cur);
        final_pwm = target_pwm(valid);
        final_rpm = avg_rpm(valid);
        final_cur = avg_cur(valid);
        
        % 3.4 Calculate Physics (Torque, Power, Eff)
        calc_torque = kt .* (final_cur - I_nl); 
        calc_torque(calc_torque < 0) = 0;
        
        calc_p_out = calc_torque .* (final_rpm * 2*pi/60);
        calc_p_out(calc_p_out < 0) = 0;
        
        calc_p_in = V_in .* final_cur;
        
        calc_eff = (calc_p_out ./ calc_p_in) * 100;
        calc_eff(isinf(calc_eff) | isnan(calc_eff)) = 0;
        
        % เก็บลง Struct
        datasets(i).freq = current_freq_val;
        datasets(i).pwm_axis = final_pwm;
        datasets(i).rpm = final_rpm;
        datasets(i).curr = final_cur;
        datasets(i).eff = calc_eff;
        
    catch ME
        errordlg(['Error processing dataset ' num2str(i) ': ' ME.message]);
        return;
    end
end

% ============================================================
% 4. PLOTTING (3 Subplots for the 3 Objectives)
% ============================================================
figure('Name', 'PWM Frequency Analysis', 'Color', 'w', 'Position', [50 50 1000 800]);
colors = lines(num_datasets); % สร้างสีแยกตามจำนวนชุดข้อมูล

% --- Plot 1: Speed vs Duty Cycle ---
subplot(3,1,1); hold on; grid on;
for i = 1:num_datasets
    plot(datasets(i).pwm_axis, datasets(i).rpm, 'o-', ...
        'LineWidth', 1.5, 'Color', colors(i,:), 'MarkerFaceColor', colors(i,:), ...
        'DisplayName', [num2str(datasets(i).freq) ' Hz']);
end
ylabel('Speed (RPM)', 'FontWeight', 'bold');
title('1. ความสัมพันธ์: ความเร็วรอบ vs Duty Cycle (แยกตามความถี่ PWM)');
legend('show', 'Location', 'best');

% --- Plot 2: Current vs Duty Cycle ---
subplot(3,1,2); hold on; grid on;
for i = 1:num_datasets
    plot(datasets(i).pwm_axis, datasets(i).curr, 's-', ...
        'LineWidth', 1.5, 'Color', colors(i,:), 'MarkerFaceColor', colors(i,:), ...
        'DisplayName', [num2str(datasets(i).freq) ' Hz']);
end
ylabel('Current (A)', 'FontWeight', 'bold');
title('2. ความสัมพันธ์: กระแสไฟฟ้า vs Duty Cycle (แยกตามความถี่ PWM)');

% --- Plot 3: Efficiency vs Duty Cycle ---
subplot(3,1,3); hold on; grid on;
for i = 1:num_datasets
    plot(datasets(i).pwm_axis, datasets(i).eff, '^-', ...
        'LineWidth', 1.5, 'Color', colors(i,:), 'MarkerFaceColor', colors(i,:), ...
        'DisplayName', [num2str(datasets(i).freq) ' Hz']);
end
ylabel('Efficiency (%)', 'FontWeight', 'bold');
xlabel('PWM Duty Cycle (%)', 'FontWeight', 'bold');
title('3. ความสัมพันธ์: ประสิทธิภาพ vs Duty Cycle (แยกตามความถี่ PWM)');
ylim([0 100]);

% Helper Function
function out = convertToDoubleArray(in)
    if isa(in, 'timeseries'), temp = in.Data;
    elseif isstruct(in) && isfield(in,'signals'), temp = in.signals.values;
    elseif iscell(in), temp = cell2mat(in);
    elseif istable(in), temp = table2array(in);
    else, temp = in; end
    out = double(temp(:));
end