%% MATLAB Script for FFT and 2nd Order Low-Pass Filter on Angular Velocity Data
%
% ไฟล์ข้อมูล: angular velocity.mat
% ตัวแปรภายใน: data (เป็นวัตถุ timeseries)
%
%--------------------------------------------------------------------------

%% 1. โหลดข้อมูลและเตรียมตัวแปร

% โหลดไฟล์ .mat
load('angular velocity.mat');

% ตรวจสอบว่าตัวแปร 'data' เป็นวัตถุ timeseries
if ~exist('data', 'var') || ~isa(data, 'timeseries')
    error('ไม่พบตัวแปร timeseries ชื่อ ''data'' ในไฟล์ angular velocity.mat หรือตัวแปรไม่ใช่ timeseries object.');
end

% แยกข้อมูลเวลา (Time) และข้อมูลความเร็วเชิงมุม (Angular Velocity)
t = data.Time;
x = data.Data;

% ลบค่าเฉลี่ย DC (ถ้ามี)
x = x - mean(x);

% กำหนดพารามิเตอร์พื้นฐานของสัญญาณ
N = length(x);              % จำนวนจุดข้อมูล
dt = t(2) - t(1);           % ช่วงเวลาในการสุ่มตัวอย่าง (สมมติว่าสม่ำเสมอ)
Fs = 1/dt;                  % ความถี่ในการสุ่มตัวอย่าง (Sampling Frequency)
T = N/Fs;                   % ระยะเวลาทั้งหมดของสัญญาณ

fprintf('จำนวนจุดข้อมูล (N): %d\n', N);
fprintf('ช่วงเวลาในการสุ่มตัวอย่าง (dt): %.4f วินาที\n', dt);
fprintf('ความถี่ในการสุ่มตัวอย่าง (Fs): %.2f Hz\n', Fs);

%--------------------------------------------------------------------------

%% 2. การแปลงฟูเรียร์อย่างรวดเร็ว (FFT) บนสัญญาณดั้งเดิม

% คำนวณ FFT
X = fft(x);

% คำนวณแกนความถี่ (Frequency Axis)
% Fs/N คือ ความละเอียดของความถี่
f = Fs*(0:(N/2))/N;

% คำนวณขนาด (Magnitude) ของสเปกตรัม
% สเปกตรัมถูกสะท้อน เราจึงสนใจเพียงครึ่งแรก (N/2 + 1 จุด)
P1_mag = abs(X/N);
P1 = P1_mag(1:N/2+1);
P1(2:end-1) = 2*P1(2:end-1); % ยกเว้น DC (จุดที่ 1) และ Nyquist (จุดสุดท้าย) ต้องคูณ 2

% พล็อตสเปกตรัมความถี่ของสัญญาณดั้งเดิม
figure;
plot(f, P1);
title('Single-Sided Amplitude Spectrum of Original Angular Velocity');
xlabel('Frequency (Hz)');
ylabel('Amplitude |P1(f)|');
grid on;

%--------------------------------------------------------------------------

%% 3. การออกแบบและการใช้ฟิลเตอร์ Low-Pass อันดับที่ 2 (2nd Order Low-Pass Filter)

% **การออกแบบฟิลเตอร์ Butterworth Low-Pass อันดับที่ 2**
% - Fc: ความถี่ตัด (Cutoff Frequency)
%   *หมายเหตุ: ปรับค่า Fc นี้ตามความเหมาะสมของสัญญาณของคุณ*
Fc = 5; % Hz (ตัวอย่าง: ตั้งค่าที่ 5 Hz เพื่อกรองสัญญาณรบกวนความถี่สูง)

% คำนวณความถี่ตัดที่ทำให้เป็นมาตรฐาน (Normalized Cutoff Frequency)
% Wn = Fc / (Fs/2) โดยที่ Fs/2 คือความถี่ Nyquist
Wn = Fc / (Fs/2);

% ออกแบบฟิลเตอร์ Butterworth
Order = 2; % กำหนดอันดับ (Order) ของฟิลเตอร์เป็น 2
[b, a] = butter(Order, Wn, 'low'); 
% b และ a คือสัมประสิทธิ์ของฟิลเตอร์

% ใช้ฟิลเตอร์กับข้อมูล
x_filtered = filtfilt(b, a, x); 
% *ใช้ filtfilt เพื่อกรองแบบไม่มีเฟสดีเลย์ (zero-phase distortion)*

%--------------------------------------------------------------------------

%% 4. พล็อตเปรียบเทียบในโดเมนเวลา (Time Domain)

figure;
subplot(2, 1, 1);
plot(t, x, 'b');
hold on;
plot(t, x_filtered, 'r', 'LineWidth', 2);
title('Original vs. Filtered Angular Velocity (Time Domain)');
xlabel('Time (s)');
ylabel('Angular Velocity');
legend('Original Signal', sprintf('Filtered (2nd Order Butterworth, Fc = %.1f Hz)', Fc));
grid on;

% พล็อตส่วนขยายเพื่อแสดงความแตกต่างที่ชัดเจนยิ่งขึ้น (ซูมเข้า)
subplot(2, 1, 2);
zoom_start = t(floor(N/4));
zoom_end = t(floor(N/4) + Fs*5); % ขยายช่วง 5 วินาที
idx = t >= zoom_start & t <= zoom_end;

plot(t(idx), x(idx), 'b');
hold on;
plot(t(idx), x_filtered(idx), 'r', 'LineWidth', 2);
title('Zoomed View: Original vs. Filtered Signal');
xlabel('Time (s)');
ylabel('Angular Velocity');
legend('Original Signal', 'Filtered Signal');
grid on;

%--------------------------------------------------------------------------

%% 5. พล็อตเปรียบเทียบในโดเมนความถี่ (Frequency Domain)

% คำนวณ FFT ของสัญญาณที่ถูกกรอง
X_filtered = fft(x_filtered);
P1_filtered_mag = abs(X_filtered/N);
P1_filtered = P1_filtered_mag(1:N/2+1);
P1_filtered(2:end-1) = 2*P1_filtered(2:end-1);

% พล็อตเปรียบเทียบสเปกตรัมความถี่
figure;
plot(f, P1, 'b');
hold on;
plot(f, P1_filtered, 'r', 'LineWidth', 2);
title('Comparison of Frequency Spectrums');
xlabel('Frequency (Hz)');
ylabel('Amplitude |P1(f)|');
xlim([0 Fs/4]); % จำกัดแกน X ให้อยู่ในช่วงความถี่ที่น่าสนใจ (ถึง Fs/4)
legend('Original Spectrum', sprintf('Filtered Spectrum (Fc = %.1f Hz)', Fc));
xline(Fc, 'k--', 'LineWidth', 1.5, 'Label', 'Cutoff Frequency (Fc)');
grid on;

%% สิ้นสุดสคริปต์