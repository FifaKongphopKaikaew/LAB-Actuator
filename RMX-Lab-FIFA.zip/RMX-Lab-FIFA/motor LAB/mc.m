% ============================================================
% MATLAB Script: DC Motor Characteristics (Single Plot Combined)
% ============================================================
clc; clear; close all;

% --- 1. Parameters ---
V_in = 12;
T_st = 0.2;   % Nm
I_st = 4.9;   % A
I_nl = 0.2;   % A

R_motor = V_in / I_st;
kt = T_st / (I_st - I_nl); 
ke = kt; 

% --- 2. Load Data (เลือกไฟล์เอง) ---
disp('--- กรุณาเลือกไฟล์ ---');
% Load Omega
[f_n, f_p] = uigetfile('*.mat', '1. เลือกไฟล์ Omega (omega2rpm.mat)');
if f_n==0, error('Cancel'); end
t = load(fullfile(f_p, f_n)); v = fieldnames(t); omega_raw = convertToDoubleArray(t.(v{1}));

% Load Frq
[f_n, f_p] = uigetfile('*.mat', '2. เลือกไฟล์ Frequency (frq.mat)');
if f_n==0, error('Cancel'); end
t = load(fullfile(f_p, f_n)); v = fieldnames(t); frq_raw = convertToDoubleArray(t.(v{1}));

% Load Current
[f_n, f_p] = uigetfile('*.mat', '3. เลือกไฟล์ Current (current.mat)');
if f_n==0, error('Cancel'); end
t = load(fullfile(f_p, f_n)); v = fieldnames(t); curr_raw = convertToDoubleArray(t.(v{1}));

% Cut Data
min_len = min([length(omega_raw), length(frq_raw), length(curr_raw)]);
limit_points = 68900; 
N = min(min_len, limit_points);
omega = omega_raw(1:N); frq = frq_raw(1:N); curr = curr_raw(1:N);

% --- Averaging ---
target_freqs = 0 : 6500 : 65000;
avg_omega = zeros(length(target_freqs),1);
avg_curr = zeros(length(target_freqs),1);
step_size = 6500;

for i = 1:length(target_freqs)
    cf = target_freqs(i);
    idx = find(frq >= (cf - step_size/2) & frq < (cf + step_size/2));
    if ~isempty(idx)
        avg_omega(i) = mean(omega(idx));
        avg_curr(i) = mean(curr(idx));
    else
        avg_omega(i) = NaN; avg_curr(i) = NaN;
    end
end

% --- 3. Calculation ---
T_plot = linspace(0, T_st, 100);
I_theory = (T_plot ./ kt) + I_nl;
w_theory = (V_in - I_theory.*R_motor) ./ ke;
n_theory = w_theory .* (60/(2*pi)); n_theory(n_theory<0)=0;
P_out_theory = T_plot .* w_theory; P_out_theory(P_out_theory<0)=0;
P_in_theory = V_in .* I_theory;
Eff_theory = (P_out_theory ./ P_in_theory) * 100;

% Exp Data
valid = ~isnan(avg_omega) & ~isnan(avg_curr) & avg_omega > 0;
exp_curr = avg_curr(valid);
exp_rpm = avg_omega(valid);
exp_torque = kt .* (exp_curr - I_nl); exp_torque(exp_torque<0)=0;
exp_p_out = exp_torque .* (exp_rpm * 2*pi/60);
exp_p_in = V_in .* exp_curr;
exp_eff = (exp_p_out ./ exp_p_in) * 100;

% ============================================================
% 4. PLOTTING (Single Subplot Combined)
% ============================================================
figure('Name', 'DC Motor Characteristics Combined', 'Color', 'w');

% --- แกนซ้าย (Left Axis): Speed ---
yyaxis left
p1 = plot(T_plot, n_theory, 'b-', 'LineWidth', 2); hold on;
p2 = plot(exp_torque, exp_rpm, 'bo', 'MarkerFaceColor', 'b', 'MarkerSize', 6);
ylabel('Speed (RPM)', 'FontSize', 12);
ax = gca; ax.YColor = 'b'; % สีแกนซ้ายเป็นสีน้ำเงิน
ylim([0 max(n_theory)*1.1]);

% --- แกนขวา (Right Axis): Current, Power, Efficiency ---
yyaxis right
% 1. Current (Red)
p3 = plot(T_plot, I_theory, 'r-', 'LineWidth', 2); hold on;
p4 = plot(exp_torque, exp_curr, 'ro', 'MarkerFaceColor', 'r', 'MarkerSize', 6);

% 2. Power Output (Brown)
p5 = plot(T_plot, P_out_theory, '-', 'Color', [0.6 0.4 0.2], 'LineWidth', 2);
p6 = plot(exp_torque, exp_p_out, '^', 'MarkerFaceColor', [0.6 0.4 0.2], 'MarkerSize', 6);

% 3. Efficiency (Green)
p7 = plot(T_plot, Eff_theory, 'g--', 'LineWidth', 2);
p8 = plot(exp_torque, exp_eff, 'gs', 'MarkerFaceColor', 'g', 'MarkerSize', 6);

ylabel('Current (A) / Power (W) / Efficiency (%)', 'FontSize', 12);
ax = gca; ax.YColor = 'k'; % สีแกนขวาเป็นสีดำ
ylim([0 100]); % ตั้ง Max 100 เพื่อรองรับ Efficiency (%)

% --- ตกแต่งกราฟ ---
xlabel('Torque (Nm)', 'FontSize', 12);
title(['DC Motor Characteristics (V_{in} = ' num2str(V_in) 'V)'], 'FontSize', 14);
grid on;

% สร้าง Legend รวม
legend([p1 p3 p5 p7], ...
       {'Speed (RPM)', 'Current (A)', 'Power (W)', 'Efficiency (%)'}, ...
       'Location', 'best');

% Helper Function
function out = convertToDoubleArray(in)
    if isa(in, 'timeseries'), temp = in.Data;
    elseif isstruct(in) && isfield(in,'signals'), temp = in.signals.values;
    elseif iscell(in), temp = cell2mat(in);
    elseif istable(in), temp = table2array(in);
    else, temp = in; end
    out = double(temp(:));
end