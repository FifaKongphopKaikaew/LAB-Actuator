% ============================================================
% MATLAB Script: Professional Split Layout (4 Scales)
% ============================================================
clc; clear; close all;

% --- 1. Parameters ---
V_in = 12;
T_st = 0.2;   % Nm
I_st = 4.9;   % A
I_nl = 0.2;   % A

R_motor = V_in / I_st;
kt = T_st / (I_st - I_nl); 
ke = kt; 

% --- 2. Load Data ---
disp('--- กรุณาเลือกไฟล์ ---');
try
    [f, p] = uigetfile('*.mat', '1. เลือกไฟล์ Omega (omega2rpm.mat)');
    if f==0, return; end; t=load(fullfile(p,f)); v=fieldnames(t); omega=convertToDoubleArray(t.(v{1}));
    
    [f, p] = uigetfile('*.mat', '2. เลือกไฟล์ Frequency (frq.mat)');
    if f==0, return; end; t=load(fullfile(p,f)); v=fieldnames(t); frq=convertToDoubleArray(t.(v{1}));
    
    [f, p] = uigetfile('*.mat', '3. เลือกไฟล์ Current (current.mat)');
    if f==0, return; end; t=load(fullfile(p,f)); v=fieldnames(t); curr=convertToDoubleArray(t.(v{1}));
catch
    error('Error loading files');
end

% Cut & Process Data
min_len = min([length(omega), length(frq), length(curr)]);
limit = 68900; N = min(min_len, limit);
omega = omega(1:N); frq = frq(1:N); curr = curr(1:N);

target_freqs = 0 : 6500 : 65000;
avg_omega = zeros(length(target_freqs),1);
avg_curr = zeros(length(target_freqs),1);
step = 6500;

for i = 1:length(target_freqs)
    cf = target_freqs(i);
    idx = find(frq >= (cf - step/2) & frq < (cf + step/2));
    if ~isempty(idx)
        avg_omega(i) = mean(omega(idx));
        avg_curr(i) = mean(curr(idx));
    else
        avg_omega(i) = NaN; avg_curr(i) = NaN;
    end
end

% --- 3. Calculation ---
T_plot = linspace(0, T_st, 100);
I_theory = (T_plot ./ kt) + I_nl;
w_theory = (V_in - I_theory.*R_motor) ./ ke;
n_theory = w_theory .* (60/(2*pi)); n_theory(n_theory<0)=0;
P_out_theory = T_plot .* w_theory; P_out_theory(P_out_theory<0)=0;
Eff_theory = (P_out_theory ./ (V_in .* I_theory)) * 100;

% Exp Data
valid = ~isnan(avg_omega) & ~isnan(avg_curr) & avg_omega > 0;
exp_curr = avg_curr(valid);
exp_rpm = avg_omega(valid);
exp_torque = kt .* (exp_curr - I_nl); exp_torque(exp_torque<0)=0;
exp_p_out = exp_torque .* (exp_rpm * 2*pi/60);
exp_eff = (exp_p_out ./ (V_in .* exp_curr)) * 100;

% ============================================================
% 4. PLOTTING (Split 2 Rows for Perfect Scaling)
% ============================================================
figure('Name', 'Professional Motor Characteristics', 'Color', 'w', 'Position', [100 50 800 900]);

% --- Graph 1 (Top): Speed (Left) vs Current (Right) ---
subplot(2,1,1);
% Left Axis: Speed (Blue)
yyaxis left
plot(T_plot, n_theory, 'b-', 'LineWidth', 2); hold on;
plot(exp_torque, exp_rpm, 'bo', 'MarkerFaceColor', 'b');
ylabel('Speed (RPM)', 'FontWeight', 'bold');
ax = gca; ax.YColor = 'b';
title(['Motor Performance (V_{in}=' num2str(V_in) 'V)'], 'FontSize', 14);
grid on;

% Right Axis: Current (Red)
yyaxis right
plot(T_plot, I_theory, 'r-', 'LineWidth', 2); hold on;
plot(exp_torque, exp_curr, 'ro', 'MarkerFaceColor', 'r');
ylabel('Current (A)', 'FontWeight', 'bold');
ax = gca; ax.YColor = 'r';
xlabel('Torque (Nm)');
legend('Speed (Theory)', 'Speed (Exp)', 'Current (Theory)', 'Current (Exp)', 'Location', 'North');

% --- Graph 2 (Bottom): Efficiency (Left) vs Power (Right) ---
subplot(2,1,2);
% Left Axis: Efficiency (Green)
yyaxis left
plot(T_plot, Eff_theory, 'g-', 'LineWidth', 2); hold on;
plot(exp_torque, exp_eff, 'gs', 'MarkerFaceColor', 'g');
ylabel('Efficiency (%)', 'FontWeight', 'bold');
ylim([0 100]); % Efficiency เต็ม 100 เสมอ
ax = gca; ax.YColor = [0 0.5 0]; % Dark Green
grid on;

% Right Axis: Power (Brown)
yyaxis right
color_pwr = [0.6 0.4 0.2];
plot(T_plot, P_out_theory, '-', 'Color', color_pwr, 'LineWidth', 2); hold on;
plot(exp_torque, exp_p_out, '^', 'MarkerFaceColor', color_pwr, 'Color', color_pwr);
ylabel('Power Output (W)', 'FontWeight', 'bold');
ax = gca; ax.YColor = color_pwr;
xlabel('Torque (Nm)');

legend('Efficiency (Theory)', 'Eff (Exp)', 'Power (Theory)', 'Power (Exp)', 'Location', 'North');

% Helper Function
function out = convertToDoubleArray(in)
    if isa(in, 'timeseries'), temp = in.Data;
    elseif isstruct(in) && isfield(in,'signals'), temp = in.signals.values;
    elseif iscell(in), temp = cell2mat(in);
    elseif istable(in), temp = table2array(in);
    else, temp = in; end
    out = double(temp(:));
end