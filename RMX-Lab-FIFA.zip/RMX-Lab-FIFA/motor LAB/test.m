%% MATLAB Script for General Low-Pass Filtering (Using filtfilt)

% -------------------------------------------------------------------------
% 1. กำหนดพารามิเตอร์การกรอง
% -------------------------------------------------------------------------

% A. ชื่อไฟล์ข้อมูลที่ต้องการกรอง
FILE_TO_FILTER = 'omega2rpm.mat'; 

% B. ความถี่ตัด (Cutoff Frequency, Fc): กำหนดความถี่สูงสุดที่ต้องการคงไว้
%    *หมายเหตุ: ปรับค่านี้ตามความเหมาะสม ถ้าสัญญาณมีความถี่หลักสูง ให้เพิ่ม Fc*
Fc = 5; % Hz (ความถี่ที่สูงกว่า 5 Hz จะถูกลดทอนลง)

% C. อันดับของฟิลเตอร์ (Filter Order): ใช้ 2nd Order Butterworth Filter
FILTER_ORDER = 2; 

fprintf('Filtering %s with Fc = %.1f Hz (Order %d)\n', FILE_TO_FILTER, Fc, FILTER_ORDER);

% -------------------------------------------------------------------------
% 2. โหลดข้อมูลและคำนวณ Fs
% -------------------------------------------------------------------------

try
    S = load(FILE_TO_FILTER);
    fields = fieldnames(S);
    ts_var_name = '';

    % ค้นหาตัวแปร Timeseries (สมมติว่าเป็นวัตถุ timeseries ตัวเดียว)
    for i = 1:length(fields)
        if isa(S.(fields{i}), 'timeseries')
            ts_var_name = fields{i};
            break;
        end
    end

    if isempty(ts_var_name)
        error('Cannot find timeseries object in the file. Check variable name.');
    end
    
    ts_raw = S.(ts_var_name);
    t = ts_raw.Time;
    x_original = ts_raw.Data;
    
    % คำนวณ Sampling Frequency (Fs)
    dt = t(2) - t(1);
    Fs = 1/dt;                  
    
    fprintf('Sampling Frequency (Fs): %.2f Hz\n', Fs);

catch ME
    fprintf('Error loading data: %s\n', ME.message);
    return;
end

% -------------------------------------------------------------------------
% 3. ออกแบบและใช้ฟิลเตอร์ (Low-Pass Filter)
% -------------------------------------------------------------------------

% คำนวณความถี่ตัดที่ทำให้เป็นมาตรฐาน (Wn = Fc / Nyquist Frequency)
Wn = Fc / (Fs/2);

% ออกแบบฟิลเตอร์ Butterworth
[b, a] = butter(FILTER_ORDER, Wn, 'low'); 

% ใช้ฟิลเตอร์กับข้อมูล
% *ใช้ filtfilt เพื่อกรองแบบไม่มีเฟสดีเลย์ (Zero-Phase Distortion)*
x_filtered = filtfilt(b, a, x_original); 

% -------------------------------------------------------------------------
% 4. พล็อตเปรียบเทียบในโดเมนเวลา
% -------------------------------------------------------------------------

figure('Name', 'Low-Pass Filter Comparison');
plot(t, x_original, 'b', 'LineWidth', 0.5);
hold on;
plot(t, x_filtered, 'r', 'LineWidth', 2);

title(sprintf('Original vs. Filtered Signal (Fc = %.1f Hz) - %s', Fc, ts_var_name));
xlabel('Time (s)');
ylabel('Amplitude');
legend('Original Signal', 'Filtered Signal', 'Location', 'best');
grid on;

%% สิ้นสุดสคริปต์