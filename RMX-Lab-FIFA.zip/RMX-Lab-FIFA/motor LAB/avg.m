%% MATLAB Script: Calculate Mean of the Low-Pass Filtered Signal

% -------------------------------------------------------------------------
% 1. กำหนดพารามิเตอร์และโหลดข้อมูล
% -------------------------------------------------------------------------

FILE_TO_ANALYZE = 'omega2rpm.mat'; % <--- เปลี่ยนชื่อไฟล์ตามความเหมาะสม
Fc = 5;                      % <--- ความถี่ตัด (Cutoff Frequency) ที่ใช้กรอง (Hz)
FILTER_ORDER = 2;            % อันดับของฟิลเตอร์

fprintf('Filtering %s with Fc = %.1f Hz (Order %d)\n', FILE_TO_ANALYZE, Fc, FILTER_ORDER);

try
    S = load(FILE_TO_ANALYZE);
    fields = fieldnames(S);
    ts_var_name = '';

    % ค้นหาตัวแปร Timeseries
    for i = 1:length(fields)
        if isa(S.(fields{i}), 'timeseries')
            ts_var_name = fields{i};
            break;
        end
    end

    if isempty(ts_var_name)
        error('Cannot find timeseries object in the file.');
    end
    
    ts_raw = S.(ts_var_name);
    t = ts_raw.Time;
    x_original = ts_raw.Data;
    
    % คำนวณ Sampling Frequency (Fs)
    dt = t(2) - t(1);
    Fs = 1/dt;                  
    
    fprintf('Sampling Frequency (Fs): %.2f Hz\n', Fs);

catch ME
    fprintf('Error loading data: %s\n', ME.message);
    return;
end

% -------------------------------------------------------------------------
% 2. Low-Pass Filter (สร้างเส้นสีแดงที่ถูกทำให้เรียบ)
% -------------------------------------------------------------------------

Wn = Fc / (Fs/2);
[b, a] = butter(FILTER_ORDER, Wn, 'low'); 

% ใช้ filtfilt เพื่อให้ได้สัญญาณที่ถูกกรองโดยไม่มี Phase Shift
x_filtered = filtfilt(b, a, x_original); 

% -------------------------------------------------------------------------
% 3. คำนวณค่าเฉลี่ยของสัญญาณที่ถูกกรอง (The Mean of the Red Line)
% -------------------------------------------------------------------------

% คำนวณค่าเฉลี่ยของเวกเตอร์สัญญาณที่ถูกกรองทั้งหมด
mean_of_filtered_signal = mean(x_filtered); 

fprintf('\n-----------------------------------------------------\n');
fprintf('Mean of the Low-Pass Filtered Signal (Fc=%.1f Hz): %.4f units\n', Fc, mean_of_filtered_signal);
fprintf('-----------------------------------------------------\n');

% -------------------------------------------------------------------------
% 4. พล็อตเพื่อตรวจสอบ
% -------------------------------------------------------------------------

figure('Name', 'Mean of Filtered Signal');
plot(t, x_original, 'b', 'LineWidth', 0.5, 'DisplayName', 'Original Data');
hold on;
plot(t, x_filtered, 'r', 'LineWidth', 2, 'DisplayName', 'Filtered Signal (Red Line)');

yline(mean_of_filtered_signal, 'k--', 'LineWidth', 1.5, ...
      'DisplayName', sprintf('Overall Mean (%.4f)', mean_of_filtered_signal));

title(sprintf('Overall Mean of Filtered Signal (Fc=%.1f Hz) - %s', Fc, ts_var_name));
xlabel('Time (s)');
ylabel('Amplitude');
legend('Location', 'best');
grid on;

%% สิ้นสุดสคริปต์