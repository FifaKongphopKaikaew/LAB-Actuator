%% MATLAB Script: Mean Calculation for a Specific Time Segment

% -------------------------------------------------------------------------
% 1. กำหนดพารามิเตอร์การกรองและช่วงเวลา
% -------------------------------------------------------------------------

FILE_TO_ANALYZE = 'omega2rpm.mat'; 
Fc = 5;               % ความถี่ตัด (Cutoff Frequency, Hz)
FILTER_ORDER = 2;

% ***************************************************************
% *** กรุณาแก้ไขค่า T_START และ T_END ***
T_START = 10; % เวลาเริ่มต้นของช่วงที่วงกลม (วินาที)
T_END = 15;   % เวลาสิ้นสุดของช่วงที่วงกลม (วินาที)
% ***************************************************************

fprintf('Analyzing segment from t=%.1f s to t=%.1f s\n', T_START, T_END);

% -------------------------------------------------------------------------
% 2. โหลดข้อมูลและกรอง (Low-Pass Filter)
% -------------------------------------------------------------------------

try
    S = load(FILE_TO_ANALYZE);
    fields = fieldnames(S);
    ts_var_name = '';

    for i = 1:length(fields)
        if isa(S.(fields{i}), 'timeseries')
            ts_var_name = fields{i};
            break;
        end
    end

    if isempty(ts_var_name)
        error('Cannot find timeseries object in the file.');
    end
    
    ts_raw = S.(ts_var_name);
    t = ts_raw.Time;
    x_original = ts_raw.Data;
    
    dt = t(2) - t(1);
    Fs = 1/dt;                  
    
    % Low-Pass Filter Design
    Wn = Fc / (Fs/2);
    [b, a] = butter(FILTER_ORDER, Wn, 'low'); 
    x_filtered = filtfilt(b, a, x_original); % สัญญาณที่ถูกกรอง (เส้นสีแดง)

catch ME
    fprintf('Error loading data: %s\n', ME.message);
    return;
end

% -------------------------------------------------------------------------
% 3. การคำนวณค่าเฉลี่ยของช่วงเวลาที่กำหนด
% -------------------------------------------------------------------------

% ค้นหา Index ของข้อมูลที่อยู่ในช่วง [T_START, T_END]
index_segment = (t >= T_START) & (t <= T_END);

% กรองสัญญาณที่ถูกกรองแล้ว (x_filtered) เฉพาะใน Segment ที่ต้องการ
segment_filtered_data = x_filtered(index_segment);

% คำนวณค่าเฉลี่ยของ Segment นั้น
mean_segment = mean(segment_filtered_data);

% คำนวณจุดเวลาตรงกลางสำหรับพล็อตจุดเดียว
t_center = (T_START + T_END) / 2;

fprintf('\n-----------------------------------------------------\n');
fprintf('Segment Mean (t=%.1f to t=%.1f): %.4f units\n', T_START, T_END, mean_segment);
fprintf('-----------------------------------------------------\n');

% -------------------------------------------------------------------------
% 4. พล็อตและแสดงจุดค่าเฉลี่ย
% -------------------------------------------------------------------------

figure('Name', 'Segment Mean Plot');

% 4.1 พล็อต Original และ Filtered Signal
plot(t, x_original, 'b', 'LineWidth', 0.5, 'DisplayName', 'Original Data');
hold on;
plot(t, x_filtered, 'r', 'LineWidth', 2, 'DisplayName', 'Filtered Signal'); 

% 4.2 เน้นช่วงที่ใช้ในการคำนวณ (Green Zone)
area(t, double(index_segment * max(x_original)), 'FaceColor', [0.8 1 0.8], ...
     'EdgeColor', 'none', 'DisplayName', 'Averaged Segment');

% 4.3 พล็อตจุดค่าเฉลี่ยเป็นจุดเดียว
plot(t_center, mean_segment, 'kp', 'MarkerSize', 15, 'LineWidth', 2, ...
     'DisplayName', sprintf('Segment Mean (%.4f)', mean_segment));

title(sprintf('Filtered Signal Mean at Segment [T=%.1f to %.1f]', T_START, T_END));
xlabel('Time (s)');
ylabel('Amplitude');
legend('Location', 'best');
grid on;

%% สิ้นสุดสคริปต์