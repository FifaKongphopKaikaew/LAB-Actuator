%% MATLAB Script for Motor Performance Curve (Final Working Version)

% -------------------------------------------------------------------------
% 1. พารามิเตอร์ที่จำเป็นต้องป้อน (User Input)
% -------------------------------------------------------------------------

T_stall = 0.2460348; % Nm
% ***กรุณาเปลี่ยนค่า 10.00 เป็นค่า I_stall ที่คุณสังเกตได้***
I_stall = 10.00; % Amps (Placeholder, ***ต้องเปลี่ยน***)

K_t = T_stall / I_stall;
fprintf('Calculated Torque Constant (Kt): %.4f Nm/A\n', K_t);

% -------------------------------------------------------------------------
% 2. โหลดและซิงโครไนซ์ข้อมูล (Fixed Synchronization Logic)
% -------------------------------------------------------------------------

try
    % --- โหลด RPM DATA ---
    S_rpm = load('rpm.mat');
    % ตามผล Diagnostic: ตัวแปร timeseries ชื่อ 'data'
    rpm_ts = S_rpm.data;
    rpm_ts.Name = 'RPM';
    
    % --- โหลด CURRENT DATA ---
    S_current = load('current.mat');
    % ตามผล Diagnostic: ตัวแปร timeseries ชื่อ 'data'
    current_ts = S_current.data;
    current_ts.Name = 'CURRENT';
    
    % --- FIX: ซิงโครไนซ์ โดยใช้ฟังก์ชัน resample เพื่อให้มั่นใจว่า Time และ Data ตรงกัน ---
    
    % 1. เลือก RPM เป็น Timeseries อ้างอิง
    ts_ref = rpm_ts;
    
    % 2. Resample Current ให้ตรงกับ Time Vector ของ RPM
    current_resampled = resample(current_ts, ts_ref.Time);
    
    % 3. สร้าง Timeseries Object สุดท้ายจากข้อมูลที่ผ่านการจัดการแล้ว
    % (ใช้โครงสร้างนี้แทน synchronize เพื่อหลีกเลี่ยง error)
    t_sync = ts_ref.Time;
    rpm_data = ts_ref.Data;
    current_data = current_resampled.Data;
    
catch ME
    fprintf('\n!!! --- FINAL ERROR REPORT --- !!!\n');
    fprintf('An error occurred. The most likely cause is an internal timeseries structure issue.\n');
    fprintf('Original Error: %s\n', ME.message);
    return;
end

% -------------------------------------------------------------------------
% 3. คำนวณ Torque และ Power
% -------------------------------------------------------------------------

Torque_data = K_t * current_data; 
Omega_data = rpm_data * (2*pi / 60); 
Power_data = Torque_data .* Omega_data; 

% -------------------------------------------------------------------------
% 4. พล็อต Torque-Speed Curve
% -------------------------------------------------------------------------

figure('Name', 'Motor Performance Curve');

% พล็อต Torque vs. RPM (T-n Curve)
subplot(2, 1, 1);
plot(rpm_data, Torque_data, '.'); 
xlabel('Speed (RPM)');
ylabel('Torque (Nm)');
title('Motor Torque-Speed Characteristic Curve (T vs. n)');
grid on;

% พล็อต Power vs. RPM (P-n Curve)
subplot(2, 1, 2);
plot(rpm_data, Power_data, '.');
xlabel('Speed (RPM)');
ylabel('Power (Watts)');
title('Motor Power-Speed Curve (P vs. n)');
grid on;