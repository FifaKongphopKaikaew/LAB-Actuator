% ============================================================
% MATLAB Script: Average Omega2RPM (Limited Data & Timeseries Support)
% ============================================================
clc; clear; close all;

% ------------------------------------------------------------
% 1. กำหนดจำนวนข้อมูลที่ต้องการจำกัด (Limit Data)
% ------------------------------------------------------------
limit_points = 115500; % กำหนดว่าจะเอาแค่ 115,500 ตัวแรก

% ------------------------------------------------------------
% 2. โหลดและจัดการข้อมูล (Load & Preprocess)
% ------------------------------------------------------------
try
    % --- Load Omega ---
    temp_rpm = load('omega2rpm.mat');
    vars_rpm = fieldnames(temp_rpm);
    raw_omega = temp_rpm.(vars_rpm{1}); 
    
    % --- Load Frq ---
    temp_frq = load('frq.mat');
    vars_frq = fieldnames(temp_frq);
    raw_frq = temp_frq.(vars_frq{1});
    
    fprintf('Load Data Complete.\n');
catch
    error('หาไฟล์ไม่เจอ! ต้องมี omega2rpm.mat และ frq.mat');
end

% --- ฟังก์ชันแปลงข้อมูลให้เป็น Double Array (รองรับ Timeseries) ---
omega = convertToDoubleArray(raw_omega);
frq   = convertToDoubleArray(raw_frq);

% --- ตัดข้อมูลให้เหลือเท่าที่กำหนด (Limit Timeseries) ---
current_len = min(length(omega), length(frq));
if current_len > limit_points
    fprintf('ตัดข้อมูลจาก %d เหลือ %d ตัวตามที่ระบุ...\n', current_len, limit_points);
    omega = omega(1:limit_points);
    frq = frq(1:limit_points);
else
    fprintf('ข้อมูลมี %d ตัว (น้อยกว่าหรือเท่ากับ %d ที่กำหนดไว้)\n', current_len, limit_points);
    % ปรับให้เท่ากันเผื่อไฟล์นึงสั้นกว่า
    omega = omega(1:current_len);
    frq = frq(1:current_len);
end

% ------------------------------------------------------------
% 3. กำหนดจุดหาค่าเฉลี่ย (0 - 65000)
% ------------------------------------------------------------
target_freqs = 0 : 6500 : 65000; 
num_targets = length(target_freqs);
avg_omega = zeros(num_targets, 1); 

step_size = 6500;
half_step = step_size / 2;

% ------------------------------------------------------------
% 4. คำนวณค่าเฉลี่ย (Processing)
% ------------------------------------------------------------
fprintf('กำลังคำนวณค่าเฉลี่ย...\n');
for i = 1:num_targets
    center_f = target_freqs(i);
    
    % หาตำแหน่งที่ frq อยู่ในช่วง (Window)
    idx = find(frq >= (center_f - half_step) & frq < (center_f + half_step));
    
    if ~isempty(idx)
        avg_omega(i) = mean(omega(idx));
    else
        avg_omega(i) = NaN; 
    end
end

% ------------------------------------------------------------
% 5. พล็อตกราฟ และ บันทึกผล
% ------------------------------------------------------------
figure('Name', 'Average Omega vs Frequency');
plot(target_freqs, avg_omega, '-o', 'LineWidth', 2, 'MarkerSize', 8, 'MarkerFaceColor', 'b');
grid on;
title(['Avg Omega vs Freq (Data limit: ' num2str(length(frq)) ')']);
xlabel('Frequency (frq)');
ylabel('Average Omega2RPM');
xticks(target_freqs); 
xtickangle(45);

ResultTable = table(target_freqs', avg_omega, 'VariableNames', {'Frequency', 'Avg_Omega'});
disp(ResultTable);
writetable(ResultTable, 'Summary_Limited_Data.csv');
fprintf('Done.\n');


% ============================================================
% ฟังก์ชันช่วยแปลงข้อมูล (อยู่ท้ายสุดของ Script)
% ============================================================
function out_array = convertToDoubleArray(in_data)
    % 1. เช็คว่าเป็น Timeseries Object หรือไม่ (Simulink ชอบใช้)
    if isa(in_data, 'timeseries')
        temp = in_data.Data; % ดึงเฉพาะเนื้อข้อมูลออกมา
    elseif isstruct(in_data) && isfield(in_data, 'signals')
        % กรณีเป็น Struct แบบ Structure with time
        temp = in_data.signals.values;
    elseif iscell(in_data)
        temp = cell2mat(in_data);
    elseif istable(in_data)
        temp = table2array(in_data);
    else
        temp = in_data;
    end
    
    % 2. แปลงเป็น double (ห้ามใช้ int)
    out_array = double(temp);
    
    % 3. บังคับเป็นแนวตั้ง (Column Vector)
    out_array = out_array(:);
end