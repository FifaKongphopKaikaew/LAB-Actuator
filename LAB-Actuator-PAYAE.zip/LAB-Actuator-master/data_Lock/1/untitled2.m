% ==============================================================================
% Script: สรุปผลการทดลอง Drive Mode (Linearity & Current)
% Output: กราฟความสัมพันธ์ Duty Cycle vs Speed/Current (รวมทุกจุดในกราฟเดียว)
% ==============================================================================
clc; clear; close all;

% --- 1. ตั้งค่า Config ---
SAMPLE_SIZE = 1000;     % จำนวนจุดที่ต้องการตัดมาหาค่าเฉลี่ย (ตรงกลาง)
TARGET_HZ = 2000;       % กรองเฉพาะความถี่นี้
TOLERANCE_HZ = 50;
MAX_PWM = 65000;        % ค่า Max ของบอร์ด

% --- 2. โหลดข้อมูล ---
fprintf('Loading Data...\n');
load('pwm.mat');              raw_pwm = double(data.Data);
load('current.mat');          raw_current = double(data.Data);
load('angular velocity.mat'); raw_rpm = double(data.Data) * 9.5493; % RPM

if isfile('frq.mat')
    load('frq.mat'); raw_frq = double(data.Data);
else
    raw_frq = ones(size(raw_pwm)) * TARGET_HZ; 
end

% --- 3. เตรียมตัวแปรเก็บผลลัพธ์ (Summary Arrays) ---
raw_pwm_clean = round(raw_pwm / 100) * 100;
unique_steps = unique(raw_pwm_clean);

% ตัวแปรที่จะเอาไปพล็อตกราฟ
list_duty = [];
list_rpm = [];
list_current = [];

fprintf('Processing %d steps...\n', length(unique_steps));

% --- 4. วนลูปหาค่าเฉลี่ยของแต่ละขั้น ---
for i = 1:length(unique_steps)
    p_val = unique_steps(i);
    
    % หาตำแหน่งข้อมูล
    idx_pwm = find(raw_pwm_clean == p_val);
    if isempty(idx_pwm), continue; end
    
    % กรองความถี่
    current_frq_segment = raw_frq(idx_pwm);
    idx_hz_match = find(abs(current_frq_segment - TARGET_HZ) <= TOLERANCE_HZ);
    
    if isempty(idx_hz_match), continue; end
    
    % เช็คความยาวข้อมูล
    valid_indices = idx_pwm(idx_hz_match);
    if length(valid_indices) < SAMPLE_SIZE
        continue; 
    end
    
    % --- ตัดเอาตรงกลาง (Middle Cut) ---
    mid_point = floor(length(valid_indices) / 2);
    half_window = floor(SAMPLE_SIZE / 2);
    start_cut = mid_point - half_window + 1;
    end_cut   = mid_point + half_window;
    
    final_indices = valid_indices(start_cut:end_cut);
    
    % --- คำนวณค่าเฉลี่ย (Average) ---
    avg_rpm = mean(raw_rpm(final_indices));
    avg_curr = mean(raw_current(final_indices));
    
    % --- คำนวณ Duty Cycle (%) ---
    % สูตรนี้รองรับทั้ง Sign-Mag (0-100) และ Locked-Anti (ถ้า PWM ติดลบ)
    % ถ้า Locked-Anti: -65000=0%, 0=50%, 65000=100%
    if min(unique_steps) < 0
        % สูตรสำหรับ Locked Anti-Phase
        duty_pct = 50 + (p_val / MAX_PWM * 50);
    else
        % สูตรสำหรับ Sign-Magnitude
        duty_pct = (p_val / MAX_PWM) * 100;
    end
    
    % เก็บลง List
    list_duty(end+1) = duty_pct;
    list_rpm(end+1) = avg_rpm;
    list_current(end+1) = avg_curr;
end

% --- 5. พล็อตกราฟสรุป (Plotting) ---
figure('Name', 'Drive Mode Characteristic Analysis', 'Color', 'w', 'Position', [100 100 1000 500]);

% กราฟซ้าย: Linearity (Duty Cycle vs Speed)
subplot(1, 2, 1);
plot(list_duty, list_rpm, 'b-o', 'LineWidth', 2, 'MarkerFaceColor', 'b');
xlabel('Duty Cycle (%)'); ylabel('Speed (RPM)');
title('Linearity Check: Speed vs Duty Cycle');
grid on; xlim([0 100]);
yline(0, '--k'); % เส้นแกน 0

% กราฟขวา: Current Consumption (Duty Cycle vs Current)
subplot(1, 2, 2);
plot(list_duty, list_current, 'r-s', 'LineWidth', 2, 'MarkerFaceColor', 'r');
xlabel('Duty Cycle (%)'); ylabel('Current (A)');
title('Current Consumption vs Duty Cycle');
grid on; xlim([0 100]);

% --- 6. แสดงตารางผลลัพธ์ ---
Result_Table = table(list_duty', list_rpm', list_current', ...
    'VariableNames', {'Duty_Cycle_Percent', 'Avg_RPM', 'Avg_Current'});
disp(Result_Table);