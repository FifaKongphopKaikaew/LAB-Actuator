% ==============================================================================
% Script Part 2: ดึงข้อมูลสรุปจาก Result มาทำกราฟและตาราง
% ==============================================================================

% 1. ดึงชื่อ Field ทั้งหมดที่มีใน Result (เช่น Duty_Neg_100, Duty_Neg_90...)
fields = fieldnames(Result);
num_points = length(fields);

% เตรียมตัวแปรเก็บข้อมูลสรุป
summary_duty = zeros(num_points, 1);
summary_rpm = zeros(num_points, 1);
summary_current = zeros(num_points, 1);

% 2. วนลูปดึงค่าเฉลี่ยออกมา
for i = 1:num_points
    fn = fields{i}; % ชื่อ field ปัจจุบัน
    
    % --- แปลงชื่อ Field กลับเป็นตัวเลข % Duty Cycle ---
    % ตัดคำว่า 'Duty_' ออก
    name_str = strrep(fn, 'Duty_', ''); 
    % เปลี่ยน 'Neg_' เป็นเครื่องหมายลบ '-'
    if contains(name_str, 'Neg_')
        name_str = strrep(name_str, 'Neg_', '-'); 
    end
    summary_duty(i) = str2double(name_str);
    
    % --- ดึงค่าเฉลี่ยที่คำนวณไว้แล้วใน Result ---
    summary_rpm(i) = Result.(fn).Avg_RPM;
    summary_current(i) = Result.(fn).Avg_Current;
end

% 3. คำนวณ Torque (ใช้ค่า Kt จาก Lab 1)
% *** อย่าลืมแก้เลขนี้ให้ตรงกับของคุณ ***
Kt = 0.0265; 
summary_torque = summary_current * Kt;

% 4. เรียงลำดับข้อมูล (Sort) ตาม Duty Cycle (จากลบไปบวก / น้อยไปมาก)
[summary_duty, sort_idx] = sort(summary_duty);
summary_rpm = summary_rpm(sort_idx);
summary_current = summary_current(sort_idx);
summary_torque = summary_torque(sort_idx);

% 5. สร้างตาราง Table แสดงผล
Result_Table = table(summary_duty, summary_rpm, summary_current, summary_torque, ...
    'VariableNames', {'Duty_Cycle_Percent', 'Avg_RPM', 'Avg_Current_Amp', 'Torque_Nm'});

disp('--- ตารางสรุปผลการทดลอง (Locked Anti-Phase) ---');
disp(Result_Table);

% 6. สร้างกราฟทันที
figure('Name', 'Locked Anti-Phase Characteristics', 'Color', 'w', 'Position', [100 100 1200 400]);

% กราฟ 1: Linearity (Duty vs Speed)
subplot(1, 3, 1);
plot(summary_duty, summary_rpm, 'b-o', 'LineWidth', 1.5, 'MarkerFaceColor', 'b');
xlabel('Duty Cycle (%)'); ylabel('Speed (RPM)');
title('Linearity: Duty vs Speed');
grid on; yline(0, '--k'); xline(0, '--k'); % เส้นแกน 0

% กราฟ 2: Speed vs Torque
subplot(1, 3, 2);
plot(summary_torque, summary_rpm, 'r-o', 'LineWidth', 1.5, 'MarkerFaceColor', 'r');
xlabel('Torque (Nm)'); ylabel('Speed (RPM)');
title('Motor Characteristic Curve');
grid on; yline(0, '--k'); xline(0, '--k');

% กราฟ 3: Current Profile
subplot(1, 3, 3);
plot(summary_duty, summary_current, 'g-o', 'LineWidth', 1.5, 'MarkerFaceColor', 'g');
xlabel('Duty Cycle (%)'); ylabel('Current (A)');
title('Current vs Duty Cycle');
grid on;