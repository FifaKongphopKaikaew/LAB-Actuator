% ==============================================================================
% Script แยกข้อมูล Raw Data ออกเป็นช่วงๆ ตาม Duty Cycle (Auto-Slicing)
% ==============================================================================
clc; clear; close all;

% --- 1. โหลดข้อมูล (แก้ชื่อโฟลเดอร์และชื่อไฟล์ให้ตรง) ---
% สมมติว่าไฟล์อยู่ในโฟลเดอร์ปัจจุบัน หรือแก้ path ตรงนี้
load('pwm.mat');              % ตัวแปรชื่อ Data (หรือ pwm)
raw_pwm = double(data.Data);       % เปลี่ยนชื่อให้เรียกง่าย

load('angular velocity.mat'); % ตัวแปรชื่อ Data
raw_rpm = double(data.Data) * 9.5493; % แปลง rad/s -> RPM

load('current.mat');          % ตัวแปรชื่อ Data
raw_current = double(data.Data);

% สร้างแกนเวลา (สมมติ Sampling time 0.001s)
time = (0:length(raw_pwm)-1)' * 0.001;

% --- 2. ค้นหาว่ามี Duty Cycle ไหนบ้าง (Auto Detect) ---
Max_PWM = 65000; % ค่า Max ของบอร์ด
unique_steps = unique(raw_pwm); % คำสั่งวิเศษ! หาค่าที่ไม่ซ้ำกันทั้งหมด

% ลบค่า 0 หรือค่าขยะช่วงเริ่มต้นออก (ถ้าต้องการ)
% unique_steps(unique_steps == 0) = []; 

fprintf('ตรวจพบการปรับ Duty Cycle ทั้งหมด %d ค่า ดังนี้:\n', length(unique_steps));

% --- 3. วนลูปแยกข้อมูลเก็บใส่ Structure ---
Result = struct(); % สร้างตัวแปรชุดสำหรับเก็บผลลัพธ์

for i = 1:length(unique_steps)
    p_val = unique_steps(i);
    
    % คำนวณ % Duty Cycle (เพื่อตั้งชื่อตัวแปร)
    % สำหรับ Locked-Anti: 50 + (PWM/65000 * 50)
    % สำหรับ Sign-Mag: (PWM/65000 * 100)
    % *อันนี้ใช้สูตร Sign-Mag เป็นตัวอย่าง*
    duty_pct = round((p_val / Max_PWM) * 100); 
    
    % สร้างชื่อ Field เช่น "Duty_10", "Duty_50"
    % (ถ้า Duty เป็นลบ จะตั้งชื่อว่า "Duty_Neg_10")
    if duty_pct < 0
        field_name = sprintf('Duty_Neg_%d', abs(duty_pct));
    else
        field_name = sprintf('Duty_%d', duty_pct);
    end
    
    % --- หัวใจสำคัญ: ดึง Index ของข้อมูลในช่วงนั้นมา ---
    idx = find(raw_pwm == p_val);
    
    % เก็บข้อมูลแยกลงใน Structure
    Result.(field_name).Time = time(idx);
    Result.(field_name).PWM_Val = raw_pwm(idx);
    Result.(field_name).RPM = raw_rpm(idx);
    Result.(field_name).Current = raw_current(idx);
    
    % คำนวณค่าเฉลี่ยแถมให้ด้วย (ตัดช่วงต้น 50% ทิ้งเพื่อความนิ่ง)
    stable_idx = idx(round(end*0.5):end);
    Result.(field_name).Avg_RPM = mean(raw_rpm(stable_idx));
    Result.(field_name).Avg_Current = mean(raw_current(stable_idx));
    
    fprintf('   >> แยกข้อมูล %s เสร็จแล้ว (จำนวน %d แถว)\n', field_name, length(idx));
end

fprintf('\n--- เสร็จเรียบร้อย! เรียกใช้ตัวแปร "Result" ได้เลย ---\n');