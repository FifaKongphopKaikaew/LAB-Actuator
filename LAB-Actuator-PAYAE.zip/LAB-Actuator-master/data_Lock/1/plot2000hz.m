% ==============================================================================
% Script: ดึงข้อมูล 1000 จุดตรงกลาง ของแต่ละขั้น (ที่ 2000Hz)
% Output: ตารางรวมที่มี 3 คอลัมน์ (PWM, Current, Omega)
% ==============================================================================
clc; clear; close all;

% --- 1. โหลดข้อมูล ---
% (ตรวจสอบชื่อไฟล์ให้ตรงกับในโฟลเดอร์นะครับ)
load('pwm.mat');              raw_pwm = double(data.Data);
load('current.mat');          raw_current = double(data.Data);
load('angular velocity.mat'); raw_omega = double(data.Data); % หน่วย rad/s (ถ้าจะเอา RPM ต้องคูณ 9.55)

% โหลดความถี่ (ถ้ามี) เพื่อกรองเฉพาะ 2000Hz
if isfile('frq.mat')
    load('frq.mat');          raw_frq = double(data.Data);
else
    raw_frq = ones(size(raw_pwm)) * 2000; % ถ้าไม่มีไฟล์ สมมติว่าเป็น 2000 ทั้งหมด
    warning('ไม่พบไฟล์ frq.mat -> สมมติว่าความถี่คือ 2000Hz ทั้งหมด');
end

% --- 2. ตั้งค่าการตัด ---
TARGET_HZ = 2000;       % ความถี่ที่ต้องการ
TOLERANCE_HZ = 50;      % ยอมให้ความถี่แกว่งได้ +/- 50
SAMPLE_SIZE = 100;     % จำนวนจุดที่ต้องการ (ตรงกลาง)

% ปัดเศษ PWM เพื่อหาขั้นบันได (Step)
raw_pwm_clean = round(raw_pwm / 100) * 100;
unique_steps = unique(raw_pwm_clean);

% ตัวแปรเก็บผลลัพธ์รวม
All_Data = []; 

fprintf('เริ่มกระบวนการดึงข้อมูล 1000 จุดตรงกลาง...\n');
fprintf('--------------------------------------------------\n');

% --- 3. วนลูปแต่ละขั้น PWM ---
for i = 1:length(unique_steps)
    p_val = unique_steps(i);
    
    % A. หาตำแหน่งของ PWM ค่านี้
    idx_pwm = find(raw_pwm_clean == p_val);
    
    if isempty(idx_pwm), continue; end
    
    % B. กรองเฉพาะที่ความถี่ 2000 Hz
    current_frq_segment = raw_frq(idx_pwm);
    idx_hz_match = find(abs(current_frq_segment - TARGET_HZ) <= TOLERANCE_HZ);
    
    if isempty(idx_hz_match)
        fprintf('   [SKIP] PWM %d : ไม่พบช่วงความถี่ 2000Hz\n', p_val);
        continue;
    end
    
    % ได้ index จริงในข้อมูลดิบ
    valid_indices = idx_pwm(idx_hz_match);
    
    % C. ตรวจสอบว่าข้อมูลยาวพอไหม (ต้องมีมากกว่า 1000 จุด)
    data_len = length(valid_indices);
    if data_len < SAMPLE_SIZE
        fprintf('   [SKIP] PWM %d : ข้อมูลสั้นเกินไป (%d จุด, ต้องการ %d)\n', p_val, data_len, SAMPLE_SIZE);
        continue;
    end
    
    % D. เจาะเอา 1000 จุดตรงกลาง (The Middle Cut)
    mid_point = floor(data_len / 2);
    half_window = floor(SAMPLE_SIZE / 2);
    
    start_cut = mid_point - half_window + 1;
    end_cut   = mid_point + half_window;
    
    % กันเหนียว (Index out of bound)
    if start_cut < 1, start_cut = 1; end
    if end_cut > data_len, end_cut = data_len; end
    
    final_indices = valid_indices(start_cut:end_cut);
    
    % E. ดึงข้อมูลออกมา
    extracted_pwm = raw_pwm(final_indices);
    extracted_curr = raw_current(final_indices);
    extracted_omega = raw_omega(final_indices);
    
    % รวมเข้ากองกลาง (Append)
    % [PWM, Current, Angular_Velocity]
    chunk_data = [extracted_pwm, extracted_curr, extracted_omega];
    All_Data = [All_Data; chunk_data];
    
    fprintf('   >> PWM %d : ดึงข้อมูลสำเร็จ %d จุด\n', p_val, length(final_indices));
end

% --- 4. บันทึกผลลัพธ์ ---
if ~isempty(All_Data)
    % สร้าง Table
    Result_Table = array2table(All_Data, ...
        'VariableNames', {'PWM_Raw', 'Current_A', 'Angular_Velocity_rad_s'});
    
    % Export to Excel
    filename = 'Extracted_Middle_100.xlsx';
    writetable(Result_Table, filename);
    
    fprintf('--------------------------------------------------\n');
    fprintf('บันทึกข้อมูลเสร็จสิ้น! ไฟล์ชื่อ: %s\n', filename);
    fprintf('จำนวนข้อมูลทั้งหมด: %d แถว\n', height(Result_Table));
    
    % พลอตกราฟเช็ค
    figure; 
    subplot(3,1,1); plot(All_Data(:,1)); ylabel('PWM'); title('Concatenated Data');
    subplot(3,1,2); plot(All_Data(:,2)); ylabel('Current');
    subplot(3,1,3); plot(All_Data(:,3)); ylabel('Omega');
else
    fprintf('ไม่พบข้อมูลที่ตรงตามเงื่อนไขเลยครับ ลองเช็คไฟล์ frq หรือค่า PWM ดูครับ\n');
end

% ==============================================================================
% Script Part 3: สร้างกราฟรวม (Combined Graph)
% ปรับแต่ง: แกน X สีดำ, แสดงเลขเต็ม (ไม่เอา 10^4), แกน Y แยกสีซ้ายขวา
% ==============================================================================

if ~isempty(All_Data)
    fprintf('\nกำลังสร้างกราฟ PWM vs Speed & Current (Custom Style)...\n');

    % 1. ดึงข้อมูลและหาค่าเฉลี่ย
    all_pwm_raw = All_Data(:,1);
    all_curr_raw = All_Data(:,2);
    all_omega_raw = All_Data(:,3);
    all_rpm_raw = all_omega_raw * 9.5493;

    unique_pwm = unique(all_pwm_raw);
    num_points = length(unique_pwm);

    plot_pwm = zeros(num_points, 1);
    plot_rpm = zeros(num_points, 1);
    plot_current = zeros(num_points, 1);

    for k = 1:num_points
        p_target = unique_pwm(k);
        idx_target = find(all_pwm_raw == p_target);

        plot_pwm(k) = p_target; 
        plot_rpm(k) = mean(all_rpm_raw(idx_target));
        plot_current(k) = mean(all_curr_raw(idx_target));
    end

    % --- 2. เริ่มสร้างกราฟ ---
    figure('Name', 'Combined Characteristic (Full Number X-Axis)', 'Color', 'w', 'Position', [100 100 1000 600]);
    
    % กำหนดสีธีม (Theme Colors)
    color_speed = [0 0.4470 0.7410];    % สีน้ำเงินเข้ม
    color_current = [0.8500 0.3250 0.0980]; % สีส้มอิฐ

    % --- แกนซ้าย (Left Axis): SPEED ---
    yyaxis left
    plot(plot_pwm, plot_rpm, 'o-', 'LineWidth', 2, 'MarkerSize', 6, 'MarkerFaceColor', color_speed);
    ylabel('Speed (RPM)', 'FontSize', 12, 'FontWeight', 'bold');
    
    % ปรับสีแกนซ้าย
    ax = gca;
    ax.YColor = color_speed; 

    % --- แกนขวา (Right Axis): CURRENT ---
    yyaxis right
    plot(plot_pwm, plot_current, 's-', 'LineWidth', 2, 'MarkerSize', 6, 'MarkerFaceColor', color_current);
    ylabel('Current (A)', 'FontSize', 12, 'FontWeight', 'bold');
    
    % ปรับสีแกนขวา
    ax.YColor = color_current;

    % --- 3. ปรับแต่งแกน X (ตามที่คุณขอ) ---
    xlabel('PWM Value (Count)', 'Color', 'k', 'FontSize', 12, 'FontWeight', 'bold');
    
    % !!! คำสั่งสำคัญ: ปิด Scientific Notation !!!
    ax.XAxis.Exponent = 0;  % บังคับไม่ให้โชว์ x10^4
    xtickformat('%.0f');    % บังคับให้แสดงเป็นเลขจำนวนเต็ม (Integer)
    
    % ตั้งค่าสีแกน X ให้เป็นสีดำเข้ม (Black)
    ax.XColor = 'k'; 
    
    % เพิ่ม Grid และ Title
    grid on; box on;
    ax.LineWidth = 1.2; % เส้นขอบหนาขึ้นนิดนึง
    ax.FontSize = 11;   % ขนาดตัวเลขบนแกน
    
    title('Combined Characteristic: Speed & Current vs PWM', 'Color', 'k', 'FontSize', 14, 'FontWeight', 'bold');
    
    % เส้นแกน 0
    xline(0, '--k', 'LineWidth', 1, 'HandleVisibility', 'off');

    % Legend (ป้ายกำกับ)
    legend({'Speed (RPM)', 'Current (A)'}, 'Location', 'best', 'FontSize', 11, 'TextColor', 'w', 'Color', 'k');

    fprintf('เสร็จสิ้น! กราฟแกน X สีดำและแสดงเลขเต็มเรียบร้อยครับ\n');
end