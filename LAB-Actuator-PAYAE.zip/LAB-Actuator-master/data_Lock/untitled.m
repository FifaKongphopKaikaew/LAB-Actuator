% ==============================================================================
% Script สำหรับรวบรวมข้อมูล Lab DC Motor และส่งออกเป็น Excel
% รองรับโครงสร้างโฟลเดอร์ 1, 2, 3
% ==============================================================================
clc; clear; close all;

% --- 1. การตั้งค่า (Configuration) ---
output_filename = 'Lab2_1_Data_Summary.xlsx'; % ชื่อไฟล์ Excel ที่จะส่งออก
folder_list = {'1', '2', '3'};                % รายชื่อโฟลเดอร์
sheet_names = {'DC ครั้งที่1', 'DC ครั้งที่2', 'DC ครั้งที่3'}; % ชื่อ Sheet ใน Excel

% ค่าคงที่สำหรับคำนวณ (กรุณาแก้ไขตามค่าจริงของคุณ)
Kt = 0.0265; % Motor Torque Constant (Nm/A) (แก้เป็นค่าที่คุณหาได้)
Max_PWM = 65000; % ค่า PWM สูงสุด

% ==============================================================================
% เริ่มกระบวนการวนลูปอ่านข้อมูลทีละโฟลเดอร์
% ==============================================================================
for i = 1:length(folder_list)
    curr_folder = folder_list{i};
    curr_sheet = sheet_names{i};
    
    fprintf('กำลังประมวลผลโฟลเดอร์: %s ...\n', curr_folder);
    
    % --- 2. โหลดข้อมูลจากไฟล์ .mat (ใช้ฟังก์ชัน helper ด้านล่าง) ---
    % หมายเหตุ: ฟังก์ชันจะดึงตัวแปร 'Data' ออกมาจากไฟล์
    
    try
        raw_ang_vel = load_data(fullfile(curr_folder, 'angular velocity.mat'));
        raw_current = load_data(fullfile(curr_folder, 'current.mat'));
        raw_freq    = load_data(fullfile(curr_folder, 'frq.mat'));
        raw_pwm     = load_data(fullfile(curr_folder, 'pwm.mat'));
        
        % (Optional) ถ้ามีไฟล์ rpm หรือ omega2rpm อยู่แล้วก็โหลดได้
        % แต่แนะนำให้คำนวณใหม่เพื่อให้มั่นใจว่าข้อมูลตรงกัน
        
    catch ME
        fprintf('Error: ไม่สามารถโหลดไฟล์ในโฟลเดอร์ %s ได้\n', curr_folder);
        fprintf('Message: %s\n', ME.message);
        continue; % ข้ามไปโฟลเดอร์ถัดไป
    end
    
    % --- 3. ตรวจสอบขนาดข้อมูล (Data Size Alignment) ---
    % บางครั้ง Simulink บันทึกข้อมูลมาจำนวนแถวไม่เท่ากันเป๊ะๆ ต้องตัดให้เท่ากัน
    min_len = min([length(raw_ang_vel), length(raw_current), length(raw_freq), length(raw_pwm)]);
    
    % ตัดข้อมูลให้เหลือความยาวเท่ากัน
    ang_vel = double(raw_ang_vel(1:min_len));
    current = double(raw_current(1:min_len));
    freq    = double(raw_freq(1:min_len));
    pwm     = double(raw_pwm(1:min_len));
    
    % --- 4. การคำนวณค่าต่างๆ (Calculations) ---
    
    % 4.1 คำนวณ RPM จาก Angular Velocity (rad/s)
    % สูตร: RPM = (rad/s) * 60 / (2*pi) approx (rad/s) * 9.5493
    calc_rpm = ang_vel * 9.5492968;
    
    % 4.2 คำนวณ Torque (Nm)
    % สูตร: T = Kt * Current
    calc_torque = current * Kt;
    
    % 4.3 คำนวณ Duty Cycle (%)
    calc_duty = (pwm / Max_PWM) * 100;
    
    % --- 5. สร้างตารางข้อมูล (Create Table) ---
    % ตั้งชื่อหัวข้อให้ตรงกับที่คุณต้องการ
    T = table(ang_vel, current, freq, calc_rpm, pwm, calc_duty, calc_torque);
    
    % เปลี่ยนชื่อหัวคอลัมน์ให้สวยงาม (ตรงกับ Excel)
    T.Properties.VariableNames = {...
        'Angular_Velocity_rad_s', ...
        'Current_A', ...
        'Frequency_Hz', ...
        'RPM', ...
        'PWM_Raw', ...
        'Duty_Cycle_Percent', ...
        'Torque_Nm'};
        
    % --- 6. ส่งออกไปยัง Excel (Export) ---
    fprintf('   --> กำลังเขียนลง Sheet: %s\n', curr_sheet);
    writetable(T, output_filename, 'Sheet', curr_sheet);
    
end

fprintf('\n--- เสร็จสิ้น! ไฟล์ถูกบันทึกที่: %s ---\n', output_filename);


% ==============================================================================
% Helper Function: สำหรับโหลดตัวแปร 'Data' จากไฟล์ .mat
% ==============================================================================
function data_out = load_data(filepath)
    if isfile(filepath)
        tmp = load(filepath);
        % ตรวจสอบว่าในไฟล์มีตัวแปรชื่อ Data หรือไม่
        if isfield(tmp, 'Data')
            data_out = tmp.Data;
        else
            % ถ้าไม่มีชื่อ Data ให้เอาตัวแปรแรกที่เจอ
            vars = fieldnames(tmp);
            data_out = tmp.(vars{1});
        end
    else
        error('File not found: %s', filepath);
    end
end