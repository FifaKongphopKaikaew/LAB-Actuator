% ==============================================================================
% [PART 1] ดึงข้อมูล 100 จุดตรงกลาง ของแต่ละขั้น (ที่ 2000Hz)
% ==============================================================================
clc; clear; close all;

% --- 1. โหลดข้อมูล ---
fprintf('Loading Data...\n');
% (ตรวจสอบชื่อไฟล์ให้ตรงกับในโฟลเดอร์นะครับ)
load('pwm.mat');              raw_pwm = double(data.Data);
load('current.mat');          raw_current = double(data.Data);
load('angular velocity.mat'); raw_omega = double(data.Data); % หน่วย rad/s

% โหลดความถี่ (ถ้ามี)
if isfile('frq.mat')
    load('frq.mat');          raw_frq = double(data.Data);
else
    raw_frq = ones(size(raw_pwm)) * 2000; 
    warning('ไม่พบไฟล์ frq.mat -> สมมติว่าความถี่คือ 2000Hz ทั้งหมด');
end

% --- 2. ตั้งค่าการตัด ---
TARGET_HZ = 2000;       % ความถี่ที่ต้องการ
TOLERANCE_HZ = 50;      % ยอมให้ความถี่แกว่งได้ +/- 50
SAMPLE_SIZE = 100;      % จำนวนจุดที่ต้องการ (ตรงกลาง)

% ปัดเศษ PWM เพื่อหาขั้นบันได
raw_pwm_clean = round(raw_pwm / 100) * 100;
unique_steps = unique(raw_pwm_clean);

% ตัวแปรเก็บผลลัพธ์รวม
All_Data = []; 

fprintf('เริ่มกระบวนการดึงข้อมูล %d จุดตรงกลาง...\n', SAMPLE_SIZE);
fprintf('--------------------------------------------------\n');

% --- 3. วนลูปแต่ละขั้น PWM ---
for i = 1:length(unique_steps)
    p_val = unique_steps(i);
    
    % A. หาตำแหน่งของ PWM ค่านี้
    idx_pwm = find(raw_pwm_clean == p_val);
    if isempty(idx_pwm), continue; end
    
    % B. กรองเฉพาะที่ความถี่ 2000 Hz
    current_frq_segment = raw_frq(idx_pwm);
    idx_hz_match = find(abs(current_frq_segment - TARGET_HZ) <= TOLERANCE_HZ);
    
    if isempty(idx_hz_match)
        fprintf('   [SKIP] PWM %d : ไม่พบช่วงความถี่ 2000Hz\n', p_val);
        continue;
    end
    
    valid_indices = idx_pwm(idx_hz_match);
    data_len = length(valid_indices);
    
    % C. ตรวจสอบความยาวข้อมูล
    if data_len < SAMPLE_SIZE
        fprintf('   [SKIP] PWM %d : ข้อมูลสั้นเกินไป (%d จุด)\n', p_val, data_len);
        continue;
    end
    
    % D. เจาะเอาตรงกลาง (Middle Cut)
    mid_point = floor(data_len / 2);
    half_window = floor(SAMPLE_SIZE / 2);
    start_cut = mid_point - half_window + 1;
    end_cut   = mid_point + half_window;
    
    % ป้องกัน index เกินขอบ
    if start_cut < 1, start_cut = 1; end
    if end_cut > data_len, end_cut = data_len; end
    
    final_indices = valid_indices(start_cut:end_cut);
    
    % E. ดึงข้อมูลออกมา
    extracted_pwm = raw_pwm(final_indices);
    extracted_curr = raw_current(final_indices);
    extracted_omega = raw_omega(final_indices);
    
    chunk_data = [extracted_pwm, extracted_curr, extracted_omega];
    All_Data = [All_Data; chunk_data];
    
    fprintf('   >> PWM %d : ดึงข้อมูลสำเร็จ %d จุด\n', p_val, length(final_indices));
end

% --- 4. บันทึกผลลัพธ์ ---
if ~isempty(All_Data)
    Result_Table = array2table(All_Data, ...
        'VariableNames', {'PWM_Raw', 'Current_A', 'Angular_Velocity_rad_s'});
    writetable(Result_Table, 'Extracted_Middle_100.xlsx');
    fprintf('บันทึกข้อมูล Excel เสร็จสิ้น!\n');
    
    % พลอตกราฟเช็คข้อมูลดิบ (Data Integrity Check)
    figure('Name', 'Raw Concatenated Data Check', 'Color', 'w');
    subplot(3,1,1); plot(All_Data(:,1)); ylabel('PWM'); title('Data Continuity Check'); grid on;
    subplot(3,1,2); plot(All_Data(:,2)); ylabel('Current'); grid on;
    subplot(3,1,3); plot(All_Data(:,3)); ylabel('Omega'); grid on;
else
    error('ไม่พบข้อมูลที่ตรงตามเงื่อนไขเลยครับ! ลองเช็คไฟล์ข้อมูลดูใหม่');
end

% ==============================================================================
% [PART 3] สร้างกราฟรวม (Combined Graph: Speed & Current vs PWM)
% ==============================================================================
if ~isempty(All_Data)
    fprintf('\nกำลังสร้างกราฟ Combined Characteristic...\n');

    % 1. ดึงข้อมูลและแปลงหน่วย
    all_pwm_raw = All_Data(:,1);
    all_curr_raw = All_Data(:,2);
    all_omega_raw = All_Data(:,3);
    all_rpm_raw = all_omega_raw * 9.5493; % rad/s -> RPM

    % 2. หาค่าเฉลี่ยของแต่ละขั้น PWM
    unique_pwm = unique(all_pwm_raw);
    num_points = length(unique_pwm);

    plot_pwm = zeros(num_points, 1);
    plot_rpm = zeros(num_points, 1);
    plot_current = zeros(num_points, 1);

    for k = 1:num_points
        p_target = unique_pwm(k);
        idx_target = find(all_pwm_raw == p_target);

        plot_pwm(k) = p_target; 
        plot_rpm(k) = mean(all_rpm_raw(idx_target));
        plot_current(k) = mean(all_curr_raw(idx_target));
    end

    % --- 3. เริ่มสร้างกราฟสวยๆ ---
    figure('Name', 'Combined Characteristic (Full Number X-Axis)', 'Color', 'w', 'Position', [100 100 1000 600]);
    
    % กำหนดสีธีม
    color_speed = [0 0.4470 0.7410];    % น้ำเงินเข้ม
    color_current = [0.8500 0.3250 0.0980]; % ส้มอิฐ

    % --- แกนซ้าย (SPEED) ---
    yyaxis left
    plot(plot_pwm, plot_rpm, 'o-', 'LineWidth', 2, 'MarkerSize', 6, 'MarkerFaceColor', color_speed);
    ylabel('Speed (RPM)', 'FontSize', 12, 'FontWeight', 'bold');
    ax = gca;
    ax.YColor = color_speed; 

    % --- แกนขวา (CURRENT) ---
    yyaxis right
    plot(plot_pwm, plot_current, 's-', 'LineWidth', 2, 'MarkerSize', 6, 'MarkerFaceColor', color_current);
    ylabel('Current (A)', 'FontSize', 12, 'FontWeight', 'bold');
    ax.YColor = color_current;

    % --- แกน X (PWM Raw) ---
    xlabel('PWM Value (Count)', 'Color', 'k', 'FontSize', 12, 'FontWeight', 'bold');
    
    % ปิด Scientific Notation (x10^4)
    ax.XAxis.Exponent = 0;  
    xtickformat('%.0f');    
    
    % แต่งสวย
    ax.XColor = 'k'; 
    grid on; box on;
    ax.LineWidth = 1.2; 
    ax.FontSize = 11;   
    
    title('Combined Characteristic: Speed & Current vs PWM', 'Color', 'k', 'FontSize', 14, 'FontWeight', 'bold');
    
    % เส้นแกน 0
    xline(0, '--k', 'LineWidth', 1, 'HandleVisibility', 'off');

    % Legend
    legend({'Speed (RPM)', 'Current (A)'}, 'Location', 'best', 'FontSize', 11, 'TextColor', 'w', 'Color', 'k');

    fprintf('เสร็จสิ้น! ได้กราฟสวยๆ พร้อมส่งงานแล้วครับ\n');
end